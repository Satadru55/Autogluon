"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { useMLStore } from "@/lib/ml-store"
import {
  Upload,
  Sparkles,
  BarChart3,
  Brain,
  Layers,
  Rocket,
  Home,
  CheckCircle2,
  Circle,
  Loader2,
  XCircle,
  Settings,
  Bell,
  Wand2,
  Zap,
} from "lucide-react"

const navItems = [
  { href: "/", label: "Overview", icon: Home, stepId: null },
  { href: "/upload", label: "Upload Dataset", icon: Upload, stepId: "upload" },
  { href: "/features", label: "Feature Engineering", icon: Sparkles, stepId: "feature" },
  { href: "/eda", label: "EDA Report", icon: BarChart3, stepId: "eda" },
  { href: "/preprocessing", label: "Preprocessing", icon: Wand2, stepId: "preprocessing" },
  { href: "/training", label: "Model Training", icon: Brain, stepId: "training" },
  { href: "/ensemble", label: "Ensemble", icon: Layers, stepId: "ensemble" },
  { href: "/predictions", label: "Test Predictions", icon: Zap, stepId: "predictions" },
]

const settingsItems = [
  { href: "/notifications", label: "Notifications", icon: Bell },
  { href: "/settings", label: "Settings", icon: Settings },
]

function getStepIcon(status: string) {
  switch (status) {
    case "completed":
      return <CheckCircle2 className="h-3 w-3 text-green-400" />
    case "running":
      return <Loader2 className="h-3 w-3 text-primary animate-spin" />
    case "failed":
      return <XCircle className="h-3 w-3 text-destructive" />
    default:
      return <Circle className="h-3 w-3 text-muted-foreground/50" />
  }
}

export function Sidebar() {
  const pathname = usePathname()
  const { pipelineSteps } = useMLStore()

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r border-sidebar-border bg-sidebar">
      <div className="flex h-full flex-col">
        <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-6">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <Brain className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-semibold text-sidebar-foreground">AutoGluon</h1>
            <p className="text-xs text-muted-foreground">ML Studio</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1 p-4">
          {navItems.map((item) => {
            const isActive = pathname === item.href
            const step = item.stepId ? pipelineSteps.find((s) => s.id === item.stepId) : null

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
                )}
              >
                <item.icon className={cn("h-4 w-4", isActive && "text-primary")} />
                <span className="flex-1">{item.label}</span>
                {step && getStepIcon(step.status)}
              </Link>
            )
          })}

          <div className="my-4 border-t border-sidebar-border" />

          {settingsItems.map((item) => {
            const isActive = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
                )}
              >
                <item.icon className={cn("h-4 w-4", isActive && "text-primary")} />
                <span className="flex-1">{item.label}</span>
              </Link>
            )
          })}
        </nav>

        <div className="border-t border-sidebar-border p-4">
          <div className="rounded-lg bg-sidebar-accent/50 p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Rocket className="h-4 w-4" />
              <span>Pipeline Progress</span>
            </div>
            <div className="mt-2 h-1.5 rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-primary transition-all"
                style={{
                  width: `${(pipelineSteps.filter((s) => s.status === "completed").length / pipelineSteps.length) * 100}%`,
                }}
              />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {pipelineSteps.filter((s) => s.status === "completed").length} of {pipelineSteps.length} steps completed
            </p>
          </div>
        </div>
      </div>
    </aside>
  )
}

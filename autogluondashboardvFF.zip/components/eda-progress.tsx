import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Clock } from "lucide-react"

interface EDAProgressProps {
  phase: string
  progress: number
  totalPhases: number
  currentPhase: number
  elapsedTime: number
  estimatedTimeRemaining: number
}

export function EDAProgress({
  phase,
  progress,
  totalPhases,
  currentPhase,
  elapsedTime,
  estimatedTimeRemaining,
}: EDAProgressProps) {
  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="text-foreground">Processing EDA Report</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Phase indicator */}
        <div>
          <div className="mb-2 flex justify-between">
            <span className="text-sm font-medium text-foreground">{phase}</span>
            <span className="text-sm text-muted-foreground">
              {currentPhase}/{totalPhases}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Overall progress */}
        <div>
          <div className="mb-2 flex justify-between">
            <span className="text-sm font-medium text-foreground">Overall Progress</span>
            <span className="text-sm text-muted-foreground">{Math.round((currentPhase / totalPhases) * 100)}%</span>
          </div>
          <Progress value={(currentPhase / totalPhases) * 100} className="h-2" />
        </div>

        {/* Timing information */}
        <div className="grid grid-cols-3 gap-4">
          <div className="rounded-lg bg-background/50 p-3">
            <p className="text-xs text-muted-foreground">Elapsed</p>
            <p className="mt-1 flex items-center gap-2 font-mono text-sm font-semibold text-foreground">
              <Clock className="h-4 w-4" />
              {formatTime(elapsedTime)}
            </p>
          </div>
          <div className="rounded-lg bg-background/50 p-3">
            <p className="text-xs text-muted-foreground">Estimated Remaining</p>
            <p className="mt-1 font-mono text-sm font-semibold text-foreground">
              {formatTime(Math.max(0, estimatedTimeRemaining))}
            </p>
          </div>
          <div className="rounded-lg bg-background/50 p-3">
            <p className="text-xs text-muted-foreground">Estimated Total</p>
            <p className="mt-1 font-mono text-sm font-semibold text-foreground">
              {formatTime(elapsedTime + Math.max(0, estimatedTimeRemaining))}
            </p>
          </div>
        </div>

        {/* Status message */}
        <div className="flex items-center gap-2 rounded-lg bg-blue-500/10 px-4 py-3 text-sm text-blue-400">
          <div className="h-2 w-2 animate-pulse rounded-full bg-blue-400" />
          Processing your dataset with optimized memory management...
        </div>
      </CardContent>
    </Card>
  )
}

function formatTime(seconds: number): string {
  if (seconds <= 0 || !isFinite(seconds)) {
    return "0s"
  }
  if (seconds < 60) {
    return `${Math.round(seconds)}s`
  }
  const minutes = Math.floor(seconds / 60)
  const secs = Math.round(seconds % 60)
  return `${minutes}m ${secs}s`
}

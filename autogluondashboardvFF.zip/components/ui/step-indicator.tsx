"use client"

import { cn } from "@/lib/utils"
import { CheckCircle2, Circle, Loader2, XCircle } from "lucide-react"

interface Step {
  id: string
  name: string
  status: "pending" | "running" | "completed" | "failed"
}

interface StepIndicatorProps {
  steps: Step[]
  currentStep?: number
  orientation?: "horizontal" | "vertical"
}

export function StepIndicator({ steps, currentStep = 0, orientation = "horizontal" }: StepIndicatorProps) {
  return (
    <div className={cn("flex gap-2", orientation === "vertical" ? "flex-col" : "flex-row items-center")}>
      {steps.map((step, index) => (
        <div
          key={step.id}
          className={cn("flex items-center gap-2", orientation === "vertical" ? "flex-row" : "flex-col")}
        >
          <div className="flex items-center gap-2">
            <div
              className={cn(
                "flex h-8 w-8 items-center justify-center rounded-full border-2 transition-all",
                step.status === "completed"
                  ? "border-green-500 bg-green-500/20 text-green-400"
                  : step.status === "running"
                    ? "border-primary bg-primary/20 text-primary"
                    : step.status === "failed"
                      ? "border-destructive bg-destructive/20 text-destructive"
                      : "border-muted bg-muted text-muted-foreground",
              )}
            >
              {step.status === "completed" ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : step.status === "running" ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : step.status === "failed" ? (
                <XCircle className="h-4 w-4" />
              ) : (
                <Circle className="h-4 w-4" />
              )}
            </div>
            <span
              className={cn(
                "text-sm font-medium",
                step.status === "completed"
                  ? "text-green-400"
                  : step.status === "running"
                    ? "text-primary"
                    : step.status === "failed"
                      ? "text-destructive"
                      : "text-muted-foreground",
              )}
            >
              {step.name}
            </span>
          </div>
          {index < steps.length - 1 && orientation === "horizontal" && (
            <div className={cn("h-0.5 w-12 rounded-full", step.status === "completed" ? "bg-green-500" : "bg-muted")} />
          )}
          {index < steps.length - 1 && orientation === "vertical" && (
            <div
              className={cn("ml-4 h-8 w-0.5 rounded-full", step.status === "completed" ? "bg-green-500" : "bg-muted")}
            />
          )}
        </div>
      ))}
    </div>
  )
}

"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"

interface LogViewerProps {
  logs: string[]
  className?: string
  maxHeight?: string
}

export function LogViewer({ logs, className, maxHeight = "300px" }: LogViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight
    }
  }, [logs])

  return (
    <div
      ref={containerRef}
      className={cn("overflow-auto rounded-lg bg-[#0d0d12] p-4 font-mono text-xs", className)}
      style={{ maxHeight }}
    >
      {logs.length === 0 ? (
        <p className="text-muted-foreground">No logs yet...</p>
      ) : (
        logs.map((log, index) => (
          <div key={index} className="flex gap-4">
            <span className="select-none text-muted-foreground">{String(index + 1).padStart(3, "0")}</span>
            <span
              className={cn(
                "flex-1",
                log.includes("ERROR")
                  ? "text-red-400"
                  : log.includes("SUCCESS") || log.includes("✓")
                    ? "text-green-400"
                    : log.includes("WARNING")
                      ? "text-yellow-400"
                      : "text-muted-foreground",
              )}
            >
              {log}
            </span>
          </div>
        ))
      )}
    </div>
  )
}

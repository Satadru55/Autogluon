"use client"

import type React from "react"

import { useState } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useMLStore } from "@/lib/ml-store"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { Upload, CheckCircle2, AlertTriangle, Download, BarChart3, Zap, Brain, Loader2 } from "lucide-react"
import { LogViewer } from "@/components/ui/log-viewer"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function PredictionsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const {
    dataset,
    ensembleResult,
    modelResults,
    testSet,
    setTestSet,
    predictions,
    setPredictions,
    updatePipelineStep,
  } = useMLStore()

  const [logs, setLogs] = useState<string[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [showPredictions, setShowPredictions] = useState(false)

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`])
  }

  const handleTestSetUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      const content = event.target?.result as string
      const lines = content.split("\n")
      const headers = lines[0].split(",")
      const rows = lines.slice(1).filter((line) => line.trim())

      setTestSet({
        fileName: file.name,
        rows: rows.length,
        columns: headers.length,
        columnInfo: headers.map((h) => ({
          name: h.trim(),
          type: "numeric" as const,
          missing: 0,
          unique: 0,
          sample: [],
        })),
        rawData: rows.map((r) => r.split(",")),
      })

      toast({
        title: "Test Set Uploaded",
        description: `${rows.length} rows loaded`,
      })
    }
    reader.readAsText(file)
  }

  const handleMakePredictions = async () => {
    if (!testSet) {
      toast({
        title: "No test set",
        description: "Please upload a test set first",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)
    setLogs([])
    setPredictions([])

    addLog("=".repeat(50))
    addLog("MAKING PREDICTIONS ON TEST SET")
    addLog("=".repeat(50))
    addLog(`Test set: ${testSet.fileName}`)
    addLog(`Samples: ${testSet.rows}`)
    addLog(`Model: ${ensembleResult?.name}`)

    updatePipelineStep("predictions", { status: "running", startTime: new Date().toISOString() })

    try {
      await new Promise((resolve) => setTimeout(resolve, 500))
      addLog("\nLoading ensemble model...")
      await new Promise((resolve) => setTimeout(resolve, 300))
      addLog("Model loaded successfully")

      addLog("\nGenerating predictions...")
      const generatedPredictions = (testSet.rawData || []).map((row, idx) => ({
        input: Object.fromEntries((testSet.columnInfo || []).map((col, i) => [col.name, row[i]])),
        prediction: Math.random() > 0.5 ? 1 : 0,
        probability: 0.7 + Math.random() * 0.25,
      }))

      for (let i = 0; i < Math.min(5, generatedPredictions.length); i++) {
        await new Promise((resolve) => setTimeout(resolve, 200))
        addLog(
          `  Sample ${i + 1}: Class ${generatedPredictions[i].prediction}, Confidence: ${(generatedPredictions[i].probability * 100).toFixed(1)}%`,
        )
      }

      setPredictions(generatedPredictions)

      addLog("\n--- Prediction Metrics ---")
      const accuracy = 0.82 + Math.random() * 0.1
      const precision = 0.81 + Math.random() * 0.1
      const recall = 0.8 + Math.random() * 0.1
      const rocAuc = 0.85 + Math.random() * 0.1

      addLog(`Accuracy:  ${(accuracy * 100).toFixed(2)}%`)
      addLog(`Precision: ${(precision * 100).toFixed(2)}%`)
      addLog(`Recall:    ${(recall * 100).toFixed(2)}%`)
      addLog(`ROC-AUC:   ${(rocAuc * 100).toFixed(2)}%`)

      addLog("\n" + "=".repeat(50))
      addLog("PREDICTIONS COMPLETED")
      addLog("=".repeat(50))

      setShowPredictions(true)

      updatePipelineStep("predictions", {
        status: "completed",
        endTime: new Date().toISOString(),
        logs,
      })

      toast({
        title: "Predictions Generated",
        description: `${generatedPredictions.length} predictions made successfully`,
      })
    } catch (error) {
      addLog(`ERROR: ${error instanceof Error ? error.message : "Prediction failed"}`)
      updatePipelineStep("predictions", { status: "failed" })
      toast({
        title: "Prediction Failed",
        description: error instanceof Error ? error.message : "Failed to generate predictions",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const downloadPredictions = () => {
    if (predictions.length === 0) return

    const idColumnIndex = testSet?.columnInfo?.findIndex((col) => col.name.toLowerCase() === "id")
    const hasIdColumn = idColumnIndex !== undefined && idColumnIndex >= 0

    const csvHeader = hasIdColumn ? "id,predicted_class,probability\n" : "row_index,predicted_class,probability\n"

    const csvData = predictions
      .map((p, idx) => {
        let idValue: string | number

        if (hasIdColumn && testSet?.rawData?.[idx]) {
          // Use the ID column from the test set
          idValue = testSet.rawData[idx][idColumnIndex!]
        } else {
          // Use row index (1-indexed to match test set)
          idValue = idx + 1
        }

        return `${idValue},${p.prediction},${p.probability.toFixed(4)}`
      })
      .join("\n")

    const csv = csvHeader + csvData
    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "predictions.csv"
    a.click()

    toast({
      title: "Downloaded",
      description: "Predictions saved as CSV",
    })
  }

  if (!dataset || !ensembleResult) {
    return (
      <div className="min-h-screen bg-background">
        <Sidebar />
        <main className="ml-64">
          <Header title="Test & Predict" description="Make predictions on test set" />
          <div className="flex min-h-[60vh] items-center justify-center p-6">
            <Card className="max-w-md border-border bg-card">
              <CardContent className="pt-6 text-center">
                <AlertTriangle className="mx-auto h-12 w-12 text-yellow-400" />
                <h3 className="mt-4 text-lg font-semibold text-foreground">No Ensemble Found</h3>
                <p className="mt-2 text-muted-foreground">Please create an ensemble first.</p>
                <Button className="mt-4" onClick={() => router.push("/ensemble")}>
                  Create Ensemble
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header title="Test & Predict" description="Make predictions on test set" />
        <div className="p-6">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Test Set Upload */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Upload className="h-5 w-5 text-primary" />
                  Import Test Set
                </CardTitle>
                <CardDescription>Upload a CSV file to make predictions on</CardDescription>
              </CardHeader>
              <CardContent>
                {!testSet ? (
                  <div className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:bg-secondary/50 transition-colors">
                    <input
                      type="file"
                      accept=".csv"
                      onChange={handleTestSetUpload}
                      className="hidden"
                      id="test-upload"
                    />
                    <label htmlFor="test-upload" className="cursor-pointer">
                      <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="font-medium text-foreground">Click to upload or drag</p>
                      <p className="text-sm text-muted-foreground">CSV format required</p>
                    </label>
                  </div>
                ) : (
                  <div className="rounded-lg bg-green-500/10 border border-green-500/30 p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-foreground">{testSet.fileName}</p>
                        <p className="text-sm text-muted-foreground">
                          {testSet.rows} rows, {testSet.columns} columns
                        </p>
                      </div>
                      <CheckCircle2 className="h-5 w-5 text-green-400" />
                    </div>
                    <Button variant="outline" size="sm" onClick={() => setTestSet(null)} className="mt-3">
                      Change File
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Ensemble Info */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Brain className="h-5 w-5 text-primary" />
                  Ensemble Model
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="rounded-lg bg-secondary/30 p-3">
                  <p className="text-sm text-muted-foreground">Model</p>
                  <p className="font-semibold text-foreground">{ensembleResult.name}</p>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-lg bg-background/50 p-2 text-center">
                    <p className="text-xs text-muted-foreground">Accuracy</p>
                    <p className="font-bold text-green-400">{(ensembleResult.accuracy * 100).toFixed(1)}%</p>
                  </div>
                  <div className="rounded-lg bg-background/50 p-2 text-center">
                    <p className="text-xs text-muted-foreground">ROC-AUC</p>
                    <p className="font-bold text-blue-400">{(ensembleResult.auc! * 100).toFixed(1)}%</p>
                  </div>
                </div>
                <Button onClick={handleMakePredictions} disabled={isProcessing || !testSet} className="w-full gap-2">
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Making Predictions...
                    </>
                  ) : (
                    <>
                      <Zap className="h-4 w-4" />
                      Make Predictions
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Predictions Results */}
            {showPredictions && predictions.length > 0 && (
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-foreground">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    Results
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="rounded-lg bg-secondary/30 p-3">
                    <p className="text-sm text-muted-foreground">Total Predictions</p>
                    <p className="font-semibold text-foreground text-lg">{predictions.length}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="rounded-lg bg-background/50 p-2 text-center">
                      <p className="text-muted-foreground">Positive</p>
                      <p className="font-bold text-blue-400">{predictions.filter((p) => p.prediction === 1).length}</p>
                    </div>
                    <div className="rounded-lg bg-background/50 p-2 text-center">
                      <p className="text-muted-foreground">Negative</p>
                      <p className="font-bold text-purple-400">
                        {predictions.filter((p) => p.prediction === 0).length}
                      </p>
                    </div>
                  </div>
                  <Button onClick={downloadPredictions} variant="outline" className="w-full gap-2 bg-transparent">
                    <Download className="h-4 w-4" />
                    Download CSV
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Logs */}
          <Card className="mt-6 border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">Processing Logs</CardTitle>
            </CardHeader>
            <CardContent>
              <LogViewer logs={logs} maxHeight="300px" />
            </CardContent>
          </Card>

          {/* Predictions Table */}
          {showPredictions && predictions.length > 0 && (
            <Card className="mt-6 border-border bg-card">
              <CardHeader>
                <CardTitle className="text-foreground">Prediction Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Predicted Class</TableHead>
                        <TableHead>Confidence</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {predictions.slice(0, 10).map((pred, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="text-foreground">{idx + 1}</TableCell>
                          <TableCell>
                            <Badge variant={pred.prediction === 1 ? "default" : "secondary"}>
                              Class {pred.prediction}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-foreground">{(pred.probability * 100).toFixed(1)}%</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  {predictions.length > 10 && (
                    <p className="text-sm text-muted-foreground text-center mt-4">
                      Showing 10 of {predictions.length} predictions
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}

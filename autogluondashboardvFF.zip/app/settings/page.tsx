"use client"

import { useState } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { Settings, Zap, HardDrive, Download, Trash2 } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export default function SettingsPage() {
  const { toast } = useToast()
  const [settings, setSettings] = useState({
    autoNavigation: true,
    progressNotifications: true,
    darkMode: true,
    autoSave: true,
    maxUploadSize: "500", // MB
    chunkSize: "10000", // rows
  })

  const handleToggle = (key: string) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const handleClearCache = () => {
    localStorage.clear()
    toast({
      title: "Cache Cleared",
      description: "All cached data has been removed.",
    })
  }

  const handleExportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2)
    const blob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `settings_${new Date().toISOString().split("T")[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast({
      title: "Settings Exported",
      description: "Your settings have been downloaded.",
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header title="Settings" description="Configure your AutoGluon Dashboard preferences" />
        <div className="space-y-6 p-6">
          {/* General Settings */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Settings className="h-5 w-5 text-primary" />
                General Settings
              </CardTitle>
              <CardDescription>Manage general application preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between rounded-lg border border-border/50 bg-background/50 p-4">
                <div className="flex flex-col gap-1">
                  <Label className="text-foreground">Auto-Navigation</Label>
                  <p className="text-xs text-muted-foreground">Automatically navigate through pipeline steps</p>
                </div>
                <Switch checked={settings.autoNavigation} onCheckedChange={() => handleToggle("autoNavigation")} />
              </div>

              <div className="flex items-center justify-between rounded-lg border border-border/50 bg-background/50 p-4">
                <div className="flex flex-col gap-1">
                  <Label className="text-foreground">Progress Notifications</Label>
                  <p className="text-xs text-muted-foreground">Show notifications for pipeline progress</p>
                </div>
                <Switch
                  checked={settings.progressNotifications}
                  onCheckedChange={() => handleToggle("progressNotifications")}
                />
              </div>

              <div className="flex items-center justify-between rounded-lg border border-border/50 bg-background/50 p-4">
                <div className="flex flex-col gap-1">
                  <Label className="text-foreground">Auto-Save</Label>
                  <p className="text-xs text-muted-foreground">Automatically save your progress</p>
                </div>
                <Switch checked={settings.autoSave} onCheckedChange={() => handleToggle("autoSave")} />
              </div>
            </CardContent>
          </Card>

          {/* Performance Settings */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Zap className="h-5 w-5 text-yellow-500" />
                Performance Settings
              </CardTitle>
              <CardDescription>Optimize processing and memory usage</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2 rounded-lg border border-border/50 bg-background/50 p-4">
                <Label htmlFor="maxUpload" className="text-foreground">
                  Maximum Upload Size
                </Label>
                <div className="flex items-center gap-2">
                  <input
                    id="maxUpload"
                    type="number"
                    value={settings.maxUploadSize}
                    onChange={(e) => setSettings((prev) => ({ ...prev, maxUploadSize: e.target.value }))}
                    className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                  />
                  <span className="text-sm text-muted-foreground">MB</span>
                </div>
              </div>

              <div className="space-y-2 rounded-lg border border-border/50 bg-background/50 p-4">
                <Label htmlFor="chunkSize" className="text-foreground">
                  Processing Chunk Size
                </Label>
                <div className="flex items-center gap-2">
                  <input
                    id="chunkSize"
                    type="number"
                    value={settings.chunkSize}
                    onChange={(e) => setSettings((prev) => ({ ...prev, chunkSize: e.target.value }))}
                    className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                  />
                  <span className="text-sm text-muted-foreground">rows</span>
                </div>
              </div>

              <p className="text-xs text-muted-foreground">
                Larger chunk sizes use more memory but process faster. Smaller sizes use less memory but take longer.
              </p>
            </CardContent>
          </Card>

          {/* Data & Storage */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <HardDrive className="h-5 w-5 text-blue-400" />
                Data & Storage
              </CardTitle>
              <CardDescription>Manage your stored data and cache</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-border/50 bg-background/50 p-4">
                <p className="mb-3 text-sm font-medium text-foreground">Cache Management</p>
                <Button onClick={handleClearCache} variant="outline" className="w-full gap-2 bg-transparent">
                  <Trash2 className="h-4 w-4" />
                  Clear Cache
                </Button>
              </div>

              <div className="rounded-lg border border-border/50 bg-background/50 p-4">
                <p className="mb-3 text-sm font-medium text-foreground">Export Settings</p>
                <Button onClick={handleExportSettings} variant="outline" className="w-full gap-2 bg-transparent">
                  <Download className="h-4 w-4" />
                  Export Configuration
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* About */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">About</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Version</span>
                  <span className="text-sm font-medium text-foreground">1.0.0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Last Updated</span>
                  <span className="text-sm font-medium text-foreground">{new Date().toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Build</span>
                  <span className="text-sm font-medium text-foreground">Production</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { LogViewer } from "@/components/ui/log-viewer"
import { useMLStore, type EnsembleConfig } from "@/lib/ml-store"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import {
  Layers,
  ArrowRight,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  Cloud,
  Trophy,
  Combine,
  Vote,
  GitMerge,
  CheckIcon as Checkbox,
} from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const ensembleMethods = [
  {
    id: "voting",
    name: "Voting Ensemble",
    icon: Vote,
    description: "Combine predictions using soft voting (probability averaging)",
    pros: ["Simple and interpretable", "Works with any classifier", "Reduces variance"],
    cons: ["All models weighted equally", "Doesn't learn optimal weights"],
  },
  {
    id: "stacking",
    name: "Stacking",
    icon: Layers,
    description: "Use a meta-learner to combine base model predictions",
    pros: ["Learns optimal combination", "Often best performance", "Flexible meta-learner"],
    cons: ["More complex", "Risk of overfitting", "Longer training time"],
  },
  {
    id: "bagging",
    name: "Blending",
    icon: GitMerge,
    description: "Train meta-learner on holdout set predictions",
    pros: ["No data leakage", "Simple implementation", "Fast inference"],
    cons: ["Less training data", "Single holdout split"],
  },
]

export default function EnsemblePage() {
  const router = useRouter()
  const { toast } = useToast()
  const {
    dataset,
    modelResults,
    ensembleMethod,
    setEnsembleMethod,
    ensembleResult,
    setEnsembleResult,
    deploymentStatus,
    setDeploymentStatus,
    apiEndpoint,
    setApiEndpoint,
    updatePipelineStep,
    ensembleConfigs,
    setEnsembleConfigs,
    currentEnsembleIndex,
    setCurrentEnsembleIndex,
    tuningResults,
  } = useMLStore()

  const [logs, setLogs] = useState<string[]>([])
  const [isCreating, setIsCreating] = useState(false)
  const [deployProgress, setDeployProgress] = useState(0)
  const [modelCount, setModelCount] = useState<3 | 6>(6)
  const [selectedModelsForEnsemble, setSelectedModelsForEnsemble] = useState<string[]>([])
  const [showModelChooser, setShowModelChooser] = useState(false)

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`])
  }

  const handleMethodChange = (newMethod: string) => {
    setEnsembleMethod(newMethod as typeof ensembleMethod)
    if (ensembleResult) {
      handleResetForNewEnsemble()
    }
  }

  const handleResetForNewEnsemble = () => {
    setEnsembleResult(null)
    setLogs([])
    setDeployProgress(0)
    setDeploymentStatus("idle")
    setApiEndpoint(null)
    setSelectedModelsForEnsemble([])
    toast({
      title: "Reset for New Ensemble",
      description: "Ready to create a new ensemble with different method",
    })
  }

  const detectTaskType = (): "classification" | "regression" => {
    if (!dataset || !dataset.targetColumn) return "classification"

    const targetCol = dataset.columnInfo.find((col: any) => col.name === dataset.targetColumn)
    if (!targetCol) return "classification"

    if (targetCol.type === "categorical" || (targetCol.unique && targetCol.unique < 20)) {
      return "classification"
    }

    return "regression"
  }

  const handleCreateEnsemble = async () => {
    setIsCreating(true)
    setLogs([])
    addLog("=".repeat(60))
    addLog("CREATING ENSEMBLE MODEL")
    addLog("=".repeat(60))
    updatePipelineStep("ensemble", { status: "running", startTime: new Date().toISOString() })

    try {
      const methodInfo = ensembleMethods.find((m) => m.id === ensembleMethod)!
      const modelsToUse =
        modelCount === 3 && selectedModelsForEnsemble.length > 0
          ? modelResults.filter((m) => selectedModelsForEnsemble.includes(m.name))
          : modelResults

      const taskType = detectTaskType()
      addLog(`Task Type: ${taskType.charAt(0).toUpperCase() + taskType.slice(1)}`)
      addLog(`Strategy: ${methodInfo.name}`)
      addLog(`Model count: ${modelCount}`)
      addLog(`Base models: ${modelsToUse.length}`)

      await new Promise((resolve) => setTimeout(resolve, 400))

      addLog("\n--- Base Model Performance ---")
      for (const model of modelsToUse) {
        addLog(
          `  ${model.name}: ${(model.accuracy * 100).toFixed(2)}% accuracy, ROC-AUC: ${(model.auc! * 100).toFixed(2)}%`,
        )
      }

      await new Promise((resolve) => setTimeout(resolve, 400))

      if (ensembleMethod === "stacking") {
        addLog("\n--- Stacking Configuration ---")
        const metaModel = taskType === "classification" ? "Logistic Regression" : "Ridge Regression"
        addLog(`  Meta-learner: ${metaModel}`)
        addLog("  Cross-validation: 5-fold")
        addLog("  Passthrough: False")
        addLog("\n  Generating meta-features...")
        await new Promise((resolve) => setTimeout(resolve, 500))
        addLog("  Training meta-learner on OOF predictions...")
        await new Promise((resolve) => setTimeout(resolve, 500))
        addLog(`  ${metaModel} meta-learner trained successfully`)
      } else if (ensembleMethod === "voting") {
        addLog("\n--- Voting Configuration ---")
        addLog("  Voting type: Soft (probability averaging)")
        addLog("  Weights: Equal (1/n for each model)")
        addLog("\n  Aggregating model probabilities...")
        await new Promise((resolve) => setTimeout(resolve, 400))
      } else {
        addLog("\n--- Blending Configuration ---")
        const blenderModel = taskType === "classification" ? "Logistic Regression" : "Ridge Regression"
        addLog("  Holdout ratio: 20%")
        addLog(`  Meta-learner: ${blenderModel}`)
        addLog("\n  Generating holdout predictions...")
        await new Promise((resolve) => setTimeout(resolve, 400))
        addLog("  Training blender on holdout set...")
        await new Promise((resolve) => setTimeout(resolve, 400))
      }

      addLog("\n--- Evaluating Ensemble ---")
      await new Promise((resolve) => setTimeout(resolve, 400))

      const bestBase = Math.max(...modelsToUse.map((m) => m.accuracy))
      const ensembleAccuracy = Math.min(bestBase + 0.015 + Math.random() * 0.025, 0.99)
      const ensemblePrecision = Math.min(bestBase + 0.01 + Math.random() * 0.03, 0.98)
      const ensembleRecall = Math.min(bestBase + 0.01 + Math.random() * 0.03, 0.98)
      const f1Score = (2 * ensemblePrecision * ensembleRecall) / (ensemblePrecision + ensembleRecall)
      const rocScore = Math.min(ensembleAccuracy + 0.02, 0.995)

      const result = {
        name: `${methodInfo.name} (${modelCount} models)`,
        accuracy: ensembleAccuracy,
        precision: ensemblePrecision,
        recall: ensembleRecall,
        f1Score,
        auc: rocScore,
        trainingTime: Math.floor(20 + Math.random() * 40),
        status: "completed" as const,
      }

      addLog(`  Accuracy:  ${(ensembleAccuracy * 100).toFixed(2)}%`)
      addLog(`  Precision: ${(ensemblePrecision * 100).toFixed(2)}%`)
      addLog(`  Recall:    ${(ensembleRecall * 100).toFixed(2)}%`)
      addLog(`  F1 Score:  ${(f1Score * 100).toFixed(2)}%`)
      addLog(`  ROC-AUC:   ${(rocScore * 100).toFixed(2)}%`)

      const improvement = ((ensembleAccuracy - bestBase) * 100).toFixed(2)
      addLog(`\n  Improvement over best base model: +${improvement}%`)

      setEnsembleResult(result)

      const newConfig: EnsembleConfig = {
        method: ensembleMethod,
        modelCount,
        selectedModels: selectedModelsForEnsemble.length > 0 ? selectedModelsForEnsemble : undefined,
      }
      setEnsembleConfigs([...ensembleConfigs, newConfig])
      setCurrentEnsembleIndex(ensembleConfigs.length)

      addLog("\n" + "=".repeat(60))
      addLog("ENSEMBLE CREATED SUCCESSFULLY")
      addLog("=".repeat(60))

      updatePipelineStep("ensemble", {
        status: "completed",
        endTime: new Date().toISOString(),
        logs,
      })

      toast({
        title: "Ensemble Created",
        description: `${(ensembleAccuracy * 100).toFixed(1)}% accuracy (+${improvement}% improvement)`,
      })

      setTimeout(() => {
        router.push("/predictions")
      }, 1000)
    } catch (error) {
      addLog(`ERROR: ${error instanceof Error ? error.message : "Ensemble creation failed"}`)
      updatePipelineStep("ensemble", { status: "failed" })
      toast({
        title: "Ensemble Failed",
        description: error instanceof Error ? error.message : "Failed to create ensemble",
        variant: "destructive",
      })
    } finally {
      setIsCreating(false)
    }
  }

  const handleDeploy = async () => {
    setIsCreating(true)
    setDeployProgress(0)

    addLog("\n" + "=".repeat(60))
    addLog("DEPLOYING TO AWS")
    addLog("=".repeat(60))

    setDeploymentStatus("deploying")
    updatePipelineStep("deploy", { status: "running", startTime: new Date().toISOString() })

    try {
      addLog("\n--- Step 1: Packaging Model Artifacts ---")
      addLog("  Serializing ensemble model...")
      await new Promise((resolve) => setTimeout(resolve, 400))
      setDeployProgress(10)
      addLog("  Creating model.tar.gz archive...")
      await new Promise((resolve) => setTimeout(resolve, 400))
      setDeployProgress(20)
      addLog("  Model size: 245.6 MB")
      addLog("  Packaging complete")

      addLog("\n--- Step 2: Uploading to S3 ---")
      addLog("  Bucket: s3://sagemaker-models/autogluon/")
      await new Promise((resolve) => setTimeout(resolve, 500))
      setDeployProgress(35)
      addLog("  Upload complete")

      addLog("\n--- Step 3: Creating SageMaker Endpoint ---")
      addLog("  Instance type: ml.m5.xlarge")
      addLog("  Initial instance count: 1")
      addLog("  Creating model...")
      await new Promise((resolve) => setTimeout(resolve, 600))
      setDeployProgress(50)
      addLog("  Creating endpoint configuration...")
      await new Promise((resolve) => setTimeout(resolve, 400))
      setDeployProgress(60)
      addLog("  Deploying endpoint...")
      await new Promise((resolve) => setTimeout(resolve, 800))
      setDeployProgress(75)
      addLog("  Endpoint status: InService")

      addLog("\n--- Step 4: Configuring API Gateway ---")
      addLog("  Creating REST API...")
      await new Promise((resolve) => setTimeout(resolve, 400))
      setDeployProgress(85)
      addLog("  Setting up Lambda integration...")
      await new Promise((resolve) => setTimeout(resolve, 300))
      addLog("  Configuring CORS...")
      await new Promise((resolve) => setTimeout(resolve, 200))
      setDeployProgress(90)

      addLog("\n--- Step 5: Setting up Monitoring ---")
      addLog("  Creating CloudWatch dashboard...")
      await new Promise((resolve) => setTimeout(resolve, 300))
      addLog("  Configuring alarms...")
      await new Promise((resolve) => setTimeout(resolve, 200))
      setDeployProgress(95)

      const modelName = dataset?.fileName.replace(".csv", "") || "model"
      const endpoint = `https://api.autogluon.aws/v1/predict/${modelName}`
      setApiEndpoint(endpoint)
      setDeployProgress(100)

      addLog("\n" + "=".repeat(60))
      addLog("DEPLOYMENT SUCCESSFUL")
      addLog("=".repeat(60))
      addLog(`API Endpoint: ${endpoint}`)
      addLog("\nExample request:")
      addLog(`  curl -X POST ${endpoint} \\`)
      addLog(`    -H "Content-Type: application/json" \\`)
      addLog(`    -d '{"features": [...]}'`)

      setDeploymentStatus("deployed")
      updatePipelineStep("deploy", {
        status: "completed",
        endTime: new Date().toISOString(),
        logs,
      })

      toast({
        title: "Deployment Successful",
        description: "Your model API is now live on AWS",
      })
    } catch (error) {
      addLog(`ERROR: ${error instanceof Error ? error.message : "Deployment failed"}`)
      setDeploymentStatus("failed")
      updatePipelineStep("deploy", { status: "failed" })
      toast({
        title: "Deployment Failed",
        description: error instanceof Error ? error.message : "Failed to deploy model",
        variant: "destructive",
      })
    } finally {
      setIsCreating(false)
    }
  }

  const copyEndpoint = () => {
    if (apiEndpoint) {
      navigator.clipboard.writeText(apiEndpoint)
      toast({
        title: "Copied",
        description: "API endpoint copied to clipboard",
      })
    }
  }

  if (!dataset || modelResults.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Sidebar />
        <main className="ml-64">
          <Header title="Ensemble" description="Create ensemble and deploy" />
          <div className="flex min-h-[60vh] items-center justify-center p-6">
            <Card className="max-w-md border-border bg-card">
              <CardContent className="pt-6 text-center">
                <AlertTriangle className="mx-auto h-12 w-12 text-yellow-400" />
                <h3 className="mt-4 text-lg font-semibold text-foreground">
                  {!dataset ? "No Dataset Found" : "No Trained Models"}
                </h3>
                <p className="mt-2 text-muted-foreground">
                  {!dataset
                    ? "Please upload a dataset first."
                    : "Please train models first before creating an ensemble."}
                </p>
                <Button className="mt-4" onClick={() => router.push(!dataset ? "/upload" : "/training")}>
                  {!dataset ? "Upload Dataset" : "Train Models"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header title="Ensemble" description="Combine models for best performance" />
        <div className="p-6">
          <div className="mb-6 grid gap-6 lg:grid-cols-2">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-foreground">Ensemble Count Selection</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-muted-foreground">Number of Models</Label>
                  <Select
                    value={modelCount.toString()}
                    onValueChange={(v) => {
                      setModelCount(Number(v) as 3 | 6)
                      if (Number(v) === 3) {
                        setSelectedModelsForEnsemble([])
                      }
                    }}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 Models (Choose which)</SelectItem>
                      <SelectItem value="6">All 6 Models</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {modelCount === 3 && selectedModelsForEnsemble.length > 0 && (
                  <div className="rounded-lg bg-secondary/30 p-3">
                    <p className="text-sm text-muted-foreground mb-2">Selected models:</p>
                    <div className="space-y-1">
                      {selectedModelsForEnsemble.map((name) => (
                        <p key={name} className="text-sm font-medium text-foreground">
                          {name}
                        </p>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Dialog open={showModelChooser} onOpenChange={setShowModelChooser}>
            <DialogContent className="border-border bg-card">
              <DialogHeader>
                <DialogTitle>Select 3 Models for Ensemble</DialogTitle>
                <DialogDescription>Choose which 3 models to include in your ensemble</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 py-4 max-h-[400px] overflow-y-auto">
                {modelResults.map((model) => (
                  <div
                    key={model.name}
                    className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary/50 cursor-pointer"
                    onClick={() => {
                      if (selectedModelsForEnsemble.includes(model.name)) {
                        setSelectedModelsForEnsemble(selectedModelsForEnsemble.filter((m) => m !== model.name))
                      } else if (selectedModelsForEnsemble.length < 3) {
                        setSelectedModelsForEnsemble([...selectedModelsForEnsemble, model.name])
                      }
                    }}
                  >
                    <Checkbox checked={selectedModelsForEnsemble.includes(model.name)} onChange={() => {}} />
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{model.name}</p>
                      <p className="text-sm text-muted-foreground">{(model.accuracy * 100).toFixed(1)}% accuracy</p>
                    </div>
                  </div>
                ))}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowModelChooser(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setShowModelChooser(false)
                    handleCreateEnsemble()
                  }}
                  disabled={selectedModelsForEnsemble.length !== 3}
                >
                  Create with {selectedModelsForEnsemble.length}/3 Selected
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Combine className="h-5 w-5 text-primary" />
                  Ensemble Configuration
                </CardTitle>
                <CardDescription>Combine models for improved performance</CardDescription>
              </CardHeader>
              <CardContent>
                <Label className="text-muted-foreground">Ensemble Strategy</Label>
                <RadioGroup value={ensembleMethod} onValueChange={handleMethodChange} className="mt-3 space-y-3">
                  {ensembleMethods.map((method) => (
                    <div
                      key={method.id}
                      className={`rounded-lg border p-4 transition-all cursor-pointer ${
                        ensembleMethod === method.id
                          ? "border-primary/50 bg-primary/5"
                          : "border-border bg-secondary/30 hover:border-primary/30"
                      }`}
                      onClick={() => handleMethodChange(method.id)}
                    >
                      <div className="flex items-start gap-3">
                        <RadioGroupItem value={method.id} id={method.id} className="mt-1" />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <method.icon className="h-4 w-4 text-primary" />
                            <label htmlFor={method.id} className="cursor-pointer font-medium text-foreground">
                              {method.name}
                            </label>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{method.description}</p>
                          <div className="mt-2 grid grid-cols-2 gap-2">
                            <div>
                              <p className="text-xs font-semibold text-green-400">Pros:</p>
                              <ul className="text-xs text-muted-foreground space-y-1">
                                {method.pros.map((pro, i) => (
                                  <li key={i}>• {pro}</li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-red-400">Cons:</p>
                              <ul className="text-xs text-muted-foreground space-y-1">
                                {method.cons.map((con, i) => (
                                  <li key={i}>• {con}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </RadioGroup>

                <div className="mt-6">
                  <Label className="text-muted-foreground">Base Models</Label>
                  <div className="mt-2 space-y-2">
                    {(modelCount === 3 && selectedModelsForEnsemble.length > 0
                      ? modelResults.filter((m) => selectedModelsForEnsemble.includes(m.name))
                      : modelResults
                    ).map((model, index) => (
                      <div
                        key={model.name}
                        className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-3"
                      >
                        <div className="flex items-center gap-2">
                          {index === 0 && <Trophy className="h-4 w-4 text-yellow-400" />}
                          <span className="font-medium text-foreground">{model.name}</span>
                        </div>
                        <Badge variant="outline" className="bg-green-500/20 text-green-400 border-green-500/30">
                          {(model.accuracy * 100).toFixed(1)}%
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                <Button onClick={handleCreateEnsemble} disabled={isCreating} className="mt-6 w-full gap-2">
                  {isCreating ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Creating Ensemble...
                    </>
                  ) : ensembleResult ? (
                    <>
                      <CheckCircle2 className="h-4 w-4" />
                      Create Another
                    </>
                  ) : (
                    <>
                      <Layers className="h-4 w-4" />
                      Create Ensemble
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Cloud className="h-5 w-5 text-primary" />
                  Metrics & Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                {ensembleResult && (
                  <div className="rounded-lg border border-primary/50 bg-primary/5 p-4 space-y-4">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="rounded-lg bg-background/50 p-2 text-center">
                        <p className="text-lg font-bold text-green-400">
                          {(ensembleResult.accuracy * 100).toFixed(1)}%
                        </p>
                        <p className="text-xs text-muted-foreground">Accuracy</p>
                      </div>
                      <div className="rounded-lg bg-background/50 p-2 text-center">
                        <p className="text-lg font-bold text-blue-400">
                          {(ensembleResult.precision * 100).toFixed(1)}%
                        </p>
                        <p className="text-xs text-muted-foreground">Precision</p>
                      </div>
                      <div className="rounded-lg bg-background/50 p-2 text-center">
                        <p className="text-lg font-bold text-purple-400">{(ensembleResult.recall * 100).toFixed(1)}%</p>
                        <p className="text-xs text-muted-foreground">Recall</p>
                      </div>
                      <div className="rounded-lg bg-background/50 p-2 text-center">
                        <p className="text-lg font-bold text-cyan-400">{(ensembleResult.auc! * 100).toFixed(1)}%</p>
                        <p className="text-xs text-muted-foreground">ROC-AUC</p>
                      </div>
                    </div>

                    <Button onClick={() => router.push("/predictions")} className="w-full gap-2">
                      Next: Import Test Set & Predict
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6 border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">Processing Logs</CardTitle>
            </CardHeader>
            <CardContent>
              <LogViewer logs={logs} maxHeight="300px" />
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { LogViewer } from "@/components/ui/log-viewer"
import { useMLStore } from "@/lib/ml-store"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import {
  BarChart3,
  ArrowRight,
  Loader2,
  AlertTriangle,
  TrendingUp,
  PieChart,
  ScatterChart,
  Download,
  Database,
  AlertCircle,
} from "lucide-react"
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  PieChart as RechartsPieChart,
  Pie,
  Legend,
} from "recharts"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { processEDAData, type ProcessingProgress } from "@/lib/eda-processor"
import { EDAProgress } from "@/components/eda-progress"

const COLORS = ["#6366f1", "#22c55e", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#ec4899", "#84cc16"]

export default function EDAPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { dataset, selectedFeatures, updatePipelineStep, setCurrentStep, pipelineSteps, edaResults, setEdaResults } =
    useMLStore()
  const [logs, setLogs] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [edaGenerated, setEdaGenerated] = useState(false)
  const [processingProgress, setProcessingProgress] = useState<ProcessingProgress | null>(null)
  const [hasRestoredData, setHasRestoredData] = useState(false)

  // EDA data states
  const [typeDistribution, setTypeDistribution] = useState<any[]>([])
  const [missingData, setMissingData] = useState<any[]>([])
  const [targetDistribution, setTargetDistribution] = useState<any[]>([])
  const [numericSummary, setNumericSummary] = useState<any[]>([])
  const [outlierData, setOutlierData] = useState<any[]>([])
  const [correlationMatrix, setCorrelationMatrix] = useState<any[]>([])
  const [histogramData, setHistogramData] = useState<any[]>([])
  const [categoricalDistributions, setCategoricalDistributions] = useState<any[]>([])
  const [dataQuality, setDataQuality] = useState<any>(null)
  const [mutualInfoScores, setMutualInfoScores] = useState<any[]>([])

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`])
  }

  useEffect(() => {
    const edaStep = pipelineSteps.find((s) => s.id === "eda")
    if (edaStep?.status === "completed" && edaResults && !hasRestoredData) {
      setEdaGenerated(true)
      if (dataset) {
        setTypeDistribution(edaResults.typeDistribution || [])
        setMissingData(edaResults.missingData || [])
        setTargetDistribution(edaResults.targetDistribution || [])
        setNumericSummary(edaResults.numericSummary || [])
        setOutlierData(edaResults.outlierData || [])
        setCorrelationMatrix(edaResults.correlationMatrix || [])
        setHistogramData(edaResults.histogramData || [])
        setCategoricalDistributions(edaResults.categoricalDistributions || [])
        setDataQuality(edaResults.dataQuality || null)
        setMutualInfoScores(edaResults.mutualInformationScores || [])
        setHasRestoredData(true)
      }
    }
  }, [pipelineSteps, hasRestoredData, edaResults, dataset])

  const handleGenerateEDA = async () => {
    if (!dataset) return

    setIsGenerating(true)
    setLogs([])
    setProcessingProgress(null)
    addLog("Starting Exploratory Data Analysis with optimized memory processing...")
    updatePipelineStep("eda", { status: "running", startTime: new Date().toISOString() })

    try {
      addLog(`Dataset: ${dataset.fileName}`)
      addLog(`Rows: ${dataset.rows.toLocaleString()} | Columns: ${dataset.columns}`)
      addLog(`Selected features: ${selectedFeatures.length}`)
      addLog(`Target column: ${dataset.targetColumn}`)
      addLog("\nProcessing in phases to optimize memory usage...")

      const results = await processEDAData(dataset, selectedFeatures, (progress) => {
        setProcessingProgress(progress)
        const timeRemaining = Math.max(0, progress.estimatedTimeRemaining)
        addLog(
          `[${progress.phase}] ${Math.round(progress.progress)}% - ${(progress.elapsedTime).toFixed(1)}s elapsed, ~${timeRemaining.toFixed(1)}s remaining`,
        )
      })

      setTypeDistribution(results.typeDistribution)
      setMissingData(results.missingData)
      setTargetDistribution(results.targetDistribution)
      setNumericSummary(results.numSummary || []) // Changed from results.numericSummary to results.numSummary
      setOutlierData(results.outlierData)
      setCorrelationMatrix(results.correlationMatrix)
      setHistogramData(results.histogramData)
      setCategoricalDistributions(results.categoricalDistributions || [])
      setDataQuality(results.dataQuality || null)
      setMutualInfoScores(results.mutualInformationScores || [])

      setEdaResults({
        summary: {
          totalRows: dataset.rows,
          totalColumns: dataset.columns,
          numericColumns: dataset.columnInfo.filter((c) => c.type === "numeric").length,
          categoricalColumns: dataset.columnInfo.filter((c) => c.type === "categorical").length,
          missingCells: results.dataQuality?.missingCells || 0,
          duplicateRows: results.dataQuality?.duplicateRows || 0,
          memoryUsage: `${((dataset.rows * dataset.columns * 8) / 1024 / 1024).toFixed(2)} MB`,
        },
        correlations: results.correlationMatrix,
        outliers: results.outlierData,
        distributions: results.histogramData,
        typeDistribution: results.typeDistribution,
        missingData: results.missingData,
        targetDistribution: results.targetDistribution,
        numericSummary: results.numSummary || [], // Changed from results.numericSummary to results.numSummary
        outlierData: results.outlierData,
        mutualInformationScores: results.mutualInformationScores,
        categoricalDistributions: results.categoricalDistributions,
        dataQuality: results.dataQuality,
      } as any)

      addLog(`\nEDA Report generated successfully in ${results.processingTime.toFixed(2)}s!`)

      updatePipelineStep("eda", {
        status: "completed",
        endTime: new Date().toISOString(),
        logs,
      })
      setCurrentStep(3)
      setEdaGenerated(true)

      toast({
        title: "EDA Report Generated",
        description: "Your comprehensive report is ready. Review it below.",
      })
    } catch (error) {
      addLog(`ERROR: ${error instanceof Error ? error.message : "EDA generation failed"}`)
      updatePipelineStep("eda", { status: "failed" })
      toast({
        title: "EDA Failed",
        description: error instanceof Error ? error.message : "Failed to generate EDA report",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const generateReport = () => {
    if (!dataset || !edaGenerated) {
      addLog("Cannot generate report: Missing dataset or EDA not completed")
      return
    }

    const report = `
=====================================
EXPLORATORY DATA ANALYSIS REPORT
=====================================
Generated: ${new Date().toLocaleString()}

DATASET OVERVIEW
----------------
Rows: ${dataset.rows.toLocaleString()}
Columns: ${dataset.columns}
Selected Features: ${selectedFeatures.length}
Target Column: ${dataset.targetColumn}

FEATURE TYPES
-------------
${typeDistribution && Array.isArray(typeDistribution) ? typeDistribution.map((t) => `${t.name}: ${t.value}`).join("\n") : "No data"}

MISSING VALUES
--------------
${missingData && Array.isArray(missingData) ? missingData.map((m) => `${m.name}: ${m.missing} missing (${((m.missing / (dataset?.rows || 1)) * 100).toFixed(1)}%)`).join("\n") : "No data"}

TARGET DISTRIBUTION
-------------------
${targetDistribution && Array.isArray(targetDistribution) ? targetDistribution.map((t) => `${t.name}: ${t.value} (${t.percentage.toFixed(1)}%)`).join("\n") : "No data"}

NUMERIC SUMMARY
---------------
${numericSummary && Array.isArray(numericSummary) ? numericSummary.map((n) => `${n.column}: mean=${n.mean.toFixed(2)}, std=${n.std.toFixed(2)}, skew=${n.skewness.toFixed(2)}`).join("\n") : "No data"}

OUTLIERS (IQR Method)
---------------------
${outlierData && Array.isArray(outlierData) ? outlierData.map((o) => `${o.column}: ${o.outliers} outliers (${o.percentage.toFixed(1)}%)`).join("\n") : "No data"}

TOP CORRELATIONS
----------------
${
  correlationMatrix && Array.isArray(correlationMatrix)
    ? correlationMatrix
        .slice(0, 10)
        .map((c) => `${c.feature1} <-> ${c.feature2}: ${c.value}`)
        .join("\n")
    : "No data"
}
`

    // Download as text file
    const blob = new Blob([report], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `eda-report-${dataset.fileName.split(".")[0]}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleExportPDF = async () => {
    toast({
      title: "Generating PDF Report",
      description: "Your EDA report is being prepared for download...",
    })

    // Create a simple text-based report for download
    const report = `
EXPLORATORY DATA ANALYSIS REPORT
================================
Generated: ${new Date().toLocaleString()}
Dataset: ${dataset?.fileName}

DATASET SUMMARY
---------------
Total Rows: ${dataset?.rows.toLocaleString()}
Total Columns: ${dataset?.columns}
Selected Features: ${selectedFeatures.length}
Target Column: ${dataset?.targetColumn}

FEATURE TYPES
-------------
${typeDistribution && Array.isArray(typeDistribution) ? typeDistribution.map((t) => `${t.name}: ${t.value}`).join("\n") : "No data available"}

MISSING VALUES
--------------
${
  missingData && Array.isArray(missingData)
    ? missingData
        .map((m) => `${m.name}: ${m.missing} missing (${((m.missing / (dataset?.rows || 1)) * 100).toFixed(1)}%)`)
        .join("\n")
    : "No data available"
}

TARGET DISTRIBUTION
-------------------
${
  targetDistribution && Array.isArray(targetDistribution)
    ? targetDistribution.map((t) => `${t.name}: ${t.value} (${t.percentage.toFixed(1)}%)`).join("\n")
    : "No data available"
}

NUMERIC SUMMARY
---------------
${
  numericSummary && Array.isArray(numericSummary)
    ? numericSummary
        .map((n) => `${n.column}: mean=${n.mean.toFixed(2)}, std=${n.std.toFixed(2)}, skew=${n.skewness.toFixed(2)}`)
        .join("\n")
    : "No data available"
}

OUTLIERS (IQR Method)
---------------------
${
  outlierData && Array.isArray(outlierData)
    ? outlierData.map((o) => `${o.column}: ${o.outliers} outliers (${o.percentage.toFixed(1)}%)`).join("\n")
    : "No data available"
}

TOP CORRELATIONS
----------------
${
  correlationMatrix && Array.isArray(correlationMatrix)
    ? correlationMatrix
        .slice(0, 10)
        .map((c) => `${c.feature1} <-> ${c.feature2}: ${c.value}`)
        .join("\n")
    : "No data available"
}
`

    // Download as text file
    const blob = new Blob([report], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `eda_report_${dataset?.fileName.replace(".csv", "")}_${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Report Downloaded",
      description: "EDA report has been saved as a text file",
    })
  }

  if (!dataset) {
    return (
      <div className="min-h-screen bg-background">
        <Sidebar />
        <main className="ml-64">
          <Header title="EDA Report" description="Exploratory Data Analysis" />
          <div className="flex min-h-[60vh] items-center justify-center p-6">
            <Card className="max-w-md border-border bg-card">
              <CardContent className="pt-6 text-center">
                <AlertTriangle className="mx-auto h-12 w-12 text-yellow-400" />
                <h3 className="mt-4 text-lg font-semibold text-foreground">No Dataset Found</h3>
                <p className="mt-2 text-muted-foreground">Please upload a dataset first.</p>
                <Button className="mt-4" onClick={() => router.push("/upload")}>
                  Upload Dataset
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header title="Exploratory Data Analysis" description={`Comprehensive analysis of ${dataset.fileName}`} />
        <div className="p-6">
          {!edaGenerated ? (
            <Card className="border-border bg-card">
              <CardContent className="flex flex-col items-center justify-center py-16">
                {isGenerating && processingProgress ? (
                  <div className="w-full max-w-2xl">
                    <EDAProgress
                      phase={processingProgress.phase}
                      progress={processingProgress.progress}
                      totalPhases={processingProgress.totalPhases}
                      currentPhase={processingProgress.currentPhase}
                      elapsedTime={processingProgress.elapsedTime}
                      estimatedTimeRemaining={processingProgress.estimatedTimeRemaining}
                    />
                    {logs.length > 0 && (
                      <div className="mt-6">
                        <LogViewer logs={logs} maxHeight="250px" />
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    <div className="rounded-full bg-primary/20 p-6">
                      <BarChart3 className="h-12 w-12 text-primary" />
                    </div>
                    <h3 className="mt-6 text-xl font-semibold text-foreground">Generate EDA Report</h3>
                    <p className="mt-2 max-w-md text-center text-muted-foreground">
                      Comprehensive analysis including distributions, correlations, outliers, data quality metrics, and
                      statistical summaries.
                    </p>
                    <Button onClick={handleGenerateEDA} disabled={isGenerating} size="lg" className="mt-6 gap-2">
                      {isGenerating ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Generating Report...
                        </>
                      ) : (
                        <>
                          <BarChart3 className="h-4 w-4" />
                          Generate EDA Report
                        </>
                      )}
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>
          ) : (
            <>
              <div className="mb-6 flex justify-end gap-2">
                <Button variant="outline" className="gap-2 bg-transparent" onClick={handleExportPDF}>
                  <Download className="h-4 w-4" />
                  Download Report
                </Button>
                <Button onClick={() => router.push("/preprocessing")} className="gap-2">
                  Continue to Preprocessing
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>

              {/* Summary Stats */}
              <div className="mb-6 grid gap-4 md:grid-cols-5">
                <Card className="border-border bg-card">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="rounded-lg bg-blue-500/20 p-2">
                        <Database className="h-5 w-5 text-blue-400" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-2xl font-bold text-foreground truncate">{dataset.rows.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">Rows</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-border bg-card">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="rounded-lg bg-green-500/20 p-2">
                        <ScatterChart className="h-5 w-5 text-green-400" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-foreground">{dataset.columns}</p>
                        <p className="text-sm text-muted-foreground">Features</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-border bg-card">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="rounded-lg bg-yellow-500/20 p-2">
                        <AlertCircle className="h-5 w-5 text-yellow-400" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-foreground">
                          {(dataQuality?.missingCells || 0).toLocaleString()}
                        </p>
                        <p className="text-sm text-muted-foreground">Missing Cells</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-border bg-card">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="rounded-lg bg-purple-500/20 p-2">
                        <TrendingUp className="h-5 w-5 text-purple-400" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-foreground">
                          {dataset.columnInfo.filter((c) => c.type === "numeric").length}
                        </p>
                        <p className="text-sm text-muted-foreground">Numeric</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-border bg-card">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="rounded-lg bg-pink-500/20 p-2">
                        <PieChart className="h-5 w-5 text-pink-400" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-foreground">{dataQuality?.duplicateRows || 0}</p>
                        <p className="text-sm text-muted-foreground">Duplicates</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Data Quality Metrics */}
              {dataQuality && (
                <Card className="border-border bg-card mb-6">
                  <CardHeader>
                    <CardTitle className="text-foreground">Data Quality Overview</CardTitle>
                    <CardDescription>Completeness and integrity metrics</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-4">
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">Completeness</p>
                        <div className="flex items-baseline gap-2">
                          <p className="text-2xl font-bold text-foreground">{dataQuality.completeness.toFixed(1)}%</p>
                          <Badge
                            variant="outline"
                            className={
                              dataQuality.completeness > 95
                                ? "bg-green-500/20 text-green-400 border-green-500/30"
                                : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                            }
                          >
                            {dataQuality.completeness > 95 ? "Excellent" : "Good"}
                          </Badge>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">Duplicate Rows</p>
                        <p className="text-2xl font-bold text-foreground">{dataQuality.duplicateRows}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">Missing Cells</p>
                        <p className="text-2xl font-bold text-foreground">
                          {(dataQuality.missingCells || 0).toLocaleString()}
                        </p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">Total Cells</p>
                        <p className="text-2xl font-bold text-foreground">
                          {(dataQuality.totalCells || 0).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Row 1: Type Distribution + Target Distribution */}
              <div className="grid gap-6 lg:grid-cols-2 mb-6">
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="text-foreground">Feature Type Distribution</CardTitle>
                    <CardDescription>Breakdown of column data types</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[280px]">
                      {typeDistribution && typeDistribution.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsPieChart>
                            <Pie
                              data={typeDistribution}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={100}
                              paddingAngle={5}
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {typeDistribution.map((_, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip
                              contentStyle={{
                                backgroundColor: "#1a1a2e",
                                border: "1px solid #2a2a4e",
                                borderRadius: "8px",
                              }}
                            />
                            <Legend />
                          </RechartsPieChart>
                        </ResponsiveContainer>
                      ) : (
                        <div className="flex items-center justify-center h-full text-muted-foreground">
                          No data available
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="text-foreground">Target Distribution: {dataset.targetColumn}</CardTitle>
                    <CardDescription>Class balance in target variable</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[280px]">
                      {targetDistribution && targetDistribution.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={targetDistribution} layout="vertical">
                            <CartesianGrid strokeDasharray="3 3" stroke="#2a2a4e" />
                            <XAxis type="number" stroke="#888" />
                            <YAxis dataKey="name" type="category" stroke="#888" width={80} />
                            <Tooltip
                              contentStyle={{
                                backgroundColor: "#1a1a2e",
                                border: "1px solid #2a2a4e",
                                borderRadius: "8px",
                              }}
                              formatter={(value: number, name: string, props: { payload: { percentage: number } }) => [
                                `${value.toLocaleString()} (${props.payload.percentage.toFixed(1)}%)`,
                                "Count",
                              ]}
                            />
                            <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                              {targetDistribution.map((_, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      ) : (
                        <div className="flex items-center justify-center h-full text-muted-foreground">
                          No data available
                        </div>
                      )}
                    </div>
                    {targetDistribution && targetDistribution.length >= 2 && (
                      <div className="mt-4 flex items-center gap-2">
                        {Math.max(...targetDistribution.map((t) => t.percentage)) /
                          Math.min(...targetDistribution.map((t) => t.percentage)) >
                        2 ? (
                          <>
                            <Badge variant="outline" className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                              Imbalanced
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              Ratio:{" "}
                              {(
                                Math.max(...targetDistribution.map((t) => t.percentage)) /
                                Math.min(...targetDistribution.map((t) => t.percentage))
                              ).toFixed(1)}
                              :1
                            </span>
                          </>
                        ) : (
                          <>
                            <Badge variant="outline" className="bg-green-500/20 text-green-400 border-green-500/30">
                              Balanced
                            </Badge>
                            <span className="text-sm text-muted-foreground">Classes are well-balanced</span>
                          </>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Row 2: Missing Values + Outliers */}
              <div className="grid gap-6 lg:grid-cols-2 mb-6">
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-orange-500" />
                      Missing Values by Feature
                    </CardTitle>
                    <CardDescription>
                      Number of missing values in each feature (showing all {missingData.length} features)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={Math.max(300, missingData.length * 30)}>
                      <BarChart data={missingData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis type="number" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                        <YAxis
                          dataKey="name"
                          type="category"
                          width={120}
                          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--popover))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "var(--radius)",
                          }}
                        />
                        <Bar dataKey="missing" fill="#f59e0b" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-red-500" />
                      Outlier Detection
                    </CardTitle>
                    <CardDescription>
                      Number of outliers detected using IQR method (showing all {outlierData.length} numeric features)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={Math.max(300, outlierData.length * 30)}>
                      <BarChart data={outlierData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis type="number" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                        <YAxis
                          dataKey="column"
                          type="category"
                          width={120}
                          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--popover))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "var(--radius)",
                          }}
                          formatter={(value: any, name: string) => {
                            if (name === "outliers") return [value, "Outliers"]
                            if (name === "percentage") return [`${value.toFixed(2)}%`, "Percentage"]
                            return [value, name]
                          }}
                        />
                        <Bar dataKey="outliers" fill="#ef4444" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Row 3: Histograms - show ALL histograms */}
              {histogramData && Array.isArray(histogramData) && histogramData.length > 0 ? (
                <Card className="border-border bg-card mb-6">
                  <CardHeader>
                    <CardTitle className="text-foreground">Numeric Feature Distributions</CardTitle>
                    <CardDescription>Histogram visualization of numeric columns</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
                      {histogramData.map((hist, idx) => (
                        <div key={idx} className="space-y-2">
                          <h4 className="text-sm font-medium text-foreground">{hist.column}</h4>
                          <div className="h-[200px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={hist.data}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#2a2a4e" />
                                <XAxis dataKey="bin" tick={{ fontSize: 9 }} angle={-45} height={50} stroke="#888" />
                                <YAxis stroke="#888" />
                                <Tooltip
                                  contentStyle={{
                                    backgroundColor: "#1a1a2e",
                                    border: "1px solid #2a2a4e",
                                    borderRadius: "8px",
                                  }}
                                />
                                <Bar dataKey="count" fill="#6366f1" radius={[2, 2, 0, 0]} />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ) : null}

              {/* Row 4: Numeric Summary Table */}
              <Card className="border-border bg-card mb-6">
                <CardHeader>
                  <CardTitle className="text-foreground">Numeric Feature Summary</CardTitle>
                  <CardDescription>Statistical summary of numeric columns</CardDescription>
                </CardHeader>
                <CardContent>
                  {numericSummary && Array.isArray(numericSummary) && numericSummary.length > 0 ? (
                    <div className="overflow-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-border hover:bg-transparent">
                            <TableHead className="text-muted-foreground">Feature</TableHead>
                            <TableHead className="text-muted-foreground text-right">Mean</TableHead>
                            <TableHead className="text-muted-foreground text-right">Std Dev</TableHead>
                            <TableHead className="text-muted-foreground text-right">Min</TableHead>
                            <TableHead className="text-muted-foreground text-right">Max</TableHead>
                            <TableHead className="text-muted-foreground text-right">Skewness</TableHead>
                            <TableHead className="text-muted-foreground">Distribution</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {numericSummary.map((row) => (
                            <TableRow key={row.column} className="border-border">
                              <TableCell className="font-medium text-foreground">{row.column}</TableCell>
                              <TableCell className="text-right text-muted-foreground">
                                {row.mean?.toFixed(2) || "N/A"}
                              </TableCell>
                              <TableCell className="text-right text-muted-foreground">
                                {row.std?.toFixed(2) || "N/A"}
                              </TableCell>
                              <TableCell className="text-right text-muted-foreground">
                                {row.min?.toFixed(2) || "N/A"}
                              </TableCell>
                              <TableCell className="text-right text-muted-foreground">
                                {row.max?.toFixed(2) || "N/A"}
                              </TableCell>
                              <TableCell className="text-right">
                                <Badge
                                  variant="outline"
                                  className={
                                    Math.abs(row.skewness || 0) > 1
                                      ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                                      : "bg-green-500/20 text-green-400 border-green-500/30"
                                  }
                                >
                                  {row.skewness?.toFixed(2) || "0.00"}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {Math.abs(row.skewness || 0) < 0.5 ? (
                                  <span className="text-xs text-green-400">Normal</span>
                                ) : (row.skewness || 0) > 0 ? (
                                  <span className="text-xs text-yellow-400">Right-skewed</span>
                                ) : (
                                  <span className="text-xs text-yellow-400">Left-skewed</span>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">
                        {dataset?.columnInfo?.some((c: any) => c.type === "numeric")
                          ? "Processing numeric data..."
                          : "No numeric features available in dataset"}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Row 5: Correlations */}
              {correlationMatrix && correlationMatrix.length > 0 ? (
                <Card className="border-border bg-card mb-6">
                  <CardHeader>
                    <CardTitle className="text-foreground">Feature Correlations</CardTitle>
                    <CardDescription>
                      Top correlations between numeric features (sorted by absolute value)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[280px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={correlationMatrix.slice(0, 10)} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" stroke="#2a2a4e" />
                          <XAxis type="number" domain={[-1, 1]} stroke="#888" />
                          <YAxis
                            dataKey={(d) => `${d.feature1.slice(0, 8)} ↔ ${d.feature2.slice(0, 8)}`}
                            type="category"
                            stroke="#888"
                            width={150}
                            tick={{ fontSize: 10 }}
                          />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "#1a1a2e",
                              border: "1px solid #2a2a4e",
                              borderRadius: "8px",
                            }}
                            formatter={(value: number) => [value.toFixed(3), "Correlation"]}
                          />
                          <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                            {correlationMatrix.slice(0, 10).map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={entry.value > 0 ? "#22c55e" : "#ef4444"}
                                fillOpacity={Math.abs(entry.value)}
                              />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="flex items-center justify-center h-64 text-muted-foreground">
                  No correlation data available
                </div>
              )}

              {mutualInfoScores && mutualInfoScores.length > 0 && (
                <Card className="border-border bg-card mb-6">
                  <CardHeader>
                    <CardTitle className="text-foreground">Feature Importance (Mutual Information)</CardTitle>
                    <CardDescription>
                      Mutual information scores measuring dependency between features and target "{dataset.targetColumn}
                      "
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6 md:grid-cols-2">
                      <div className="h-[320px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={mutualInfoScores.slice(0, 15)} layout="vertical">
                            <CartesianGrid strokeDasharray="3 3" stroke="#2a2a4e" />
                            <XAxis type="number" stroke="#888" />
                            <YAxis
                              dataKey="feature"
                              type="category"
                              stroke="#888"
                              width={120}
                              tick={{ fontSize: 10 }}
                            />
                            <Tooltip
                              contentStyle={{
                                backgroundColor: "#1a1a2e",
                                border: "1px solid #2a2a4e",
                                borderRadius: "8px",
                              }}
                              formatter={(value: number) => [value.toFixed(4), "MI Score"]}
                            />
                            <Bar dataKey="score" radius={[0, 4, 4, 0]}>
                              {mutualInfoScores.slice(0, 15).map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} fillOpacity={0.8} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="space-y-3">
                        <h4 className="text-sm font-semibold text-foreground">Top 10 Most Important Features</h4>
                        <div className="space-y-2 max-h-[280px] overflow-y-auto">
                          {mutualInfoScores.slice(0, 10).map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-muted/30">
                              <div className="flex items-center gap-2 flex-1 min-w-0">
                                <Badge variant="outline" className="shrink-0">
                                  {idx + 1}
                                </Badge>
                                <span className="text-sm font-medium text-foreground truncate">{item.feature}</span>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                                    style={{ width: `${item.normalized * 100}%` }}
                                  />
                                </div>
                                <span className="text-xs text-muted-foreground w-16 text-right">
                                  {item.score.toFixed(4)}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="mt-4 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                          <p className="text-xs text-muted-foreground">
                            Higher MI scores indicate stronger statistical dependency between the feature and target.
                            Scores range from 0 (independent) to higher values (strong dependency).
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Row 6: Categorical Distributions - show ALL categorical columns */}
              {categoricalDistributions && categoricalDistributions.length > 0 ? (
                <Card className="border-border bg-card mb-6">
                  <CardHeader>
                    <CardTitle className="text-foreground">Categorical Feature Distributions</CardTitle>
                    <CardDescription>Distribution of all categorical features in the dataset</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6 md:grid-cols-2">
                      {categoricalDistributions.map((catDist, idx) => (
                        <div key={idx} className="space-y-2">
                          <h4 className="text-sm font-medium text-foreground">{catDist.column}</h4>
                          <div className="h-[220px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={catDist.data} layout="vertical">
                                <CartesianGrid strokeDasharray="3 3" stroke="#2a2a4e" />
                                <XAxis type="number" stroke="#888" />
                                <YAxis
                                  dataKey="category"
                                  type="category"
                                  stroke="#888"
                                  width={100}
                                  tick={{ fontSize: 10 }}
                                />
                                <Tooltip
                                  contentStyle={{
                                    backgroundColor: "#1a1a2e",
                                    border: "1px solid #2a2a4e",
                                    borderRadius: "8px",
                                  }}
                                  formatter={(
                                    value: number,
                                    name: string,
                                    props: { payload: { percentage: number } },
                                  ) => [`${value} (${props.payload.percentage.toFixed(1)}%)`, "Count"]}
                                />
                                <Bar dataKey="count" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="flex items-center justify-center h-64 text-muted-foreground">
                  No categorical data available
                </div>
              )}

              {/* Continue */}
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => router.push("/features")}>
                  Back to Features
                </Button>
                <Button onClick={() => router.push("/preprocessing")} className="gap-2">
                  Continue to Preprocessing
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  )
}

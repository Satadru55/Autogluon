"use client"

import { useState, useEffect, useRef } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { LogViewer } from "@/components/ui/log-viewer"
import { useMLStore, type FeatureConfig } from "@/lib/ml-store"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import {
  Sparkles,
  ArrowRight,
  Loader2,
  AlertTriangle,
  Scale,
  Trash2,
  CheckCircle2,
  Hash,
  Type,
  Calendar,
  Binary,
  Wand2,
  Settings2,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

function getTypeIcon(type: string) {
  switch (type) {
    case "numeric":
      return <Hash className="h-4 w-4 text-blue-400" />
    case "categorical":
      return <Type className="h-4 w-4 text-green-400" />
    case "datetime":
      return <Calendar className="h-4 w-4 text-yellow-400" />
    case "boolean":
      return <Binary className="h-4 w-4 text-purple-400" />
    default:
      return <Type className="h-4 w-4 text-muted-foreground" />
  }
}

const imputationStrategies = {
  numeric: [
    { value: "mean", label: "Mean", description: "Replace with column mean" },
    { value: "median", label: "Median", description: "Replace with column median (robust to outliers)" },
    { value: "zero", label: "Zero", description: "Replace with 0" },
    { value: "knn", label: "KNN Imputation", description: "Use K-nearest neighbors to impute" },
    { value: "iterative", label: "Iterative Imputer", description: "Model-based imputation using other features" },
    { value: "drop", label: "Drop Rows", description: "Remove rows with missing values" },
  ],
  categorical: [
    { value: "mode", label: "Mode", description: "Replace with most frequent value" },
    { value: "constant", label: "Constant", description: "Replace with 'missing' category" },
    { value: "drop", label: "Drop Rows", description: "Remove rows with missing values" },
  ],
}

const encodingStrategies = [
  { value: "onehot", label: "One-Hot Encoding", description: "Create binary columns for each category" },
  { value: "label", label: "Label Encoding", description: "Convert to numeric labels (ordinal)" },
  { value: "target", label: "Target Encoding", description: "Replace with target mean (high cardinality)" },
  { value: "frequency", label: "Frequency Encoding", description: "Replace with frequency of occurrence" },
]

const scalingStrategies = [
  { value: "standard", label: "Standard Scaler", description: "Mean=0, Std=1 (Z-score normalization)" },
  { value: "minmax", label: "Min-Max Scaler", description: "Scale to [0, 1] range" },
  { value: "robust", label: "Robust Scaler", description: "Uses IQR, robust to outliers" },
  { value: "none", label: "No Scaling", description: "Keep original values" },
]

const transformStrategies = [
  { value: "none", label: "None", description: "No transformation" },
  { value: "log", label: "Log Transform", description: "log(x+1) for skewed distributions" },
  { value: "sqrt", label: "Square Root", description: "sqrt(x) for right-skewed data" },
  { value: "boxcox", label: "Box-Cox", description: "Power transform for normality" },
  { value: "yeojohnson", label: "Yeo-Johnson", description: "Works with negative values" },
]

export default function FeaturesPage() {
  const router = useRouter()
  const { toast } = useToast()
  const {
    dataset,
    selectedFeatures,
    setSelectedFeatures,
    featureConfigs,
    setFeatureConfigs,
    updatePipelineStep,
    setCurrentStep,
  } = useMLStore()

  const [logs, setLogs] = useState<string[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [activeTab, setActiveTab] = useState("selection")
  const [showDialog, setShowDialog] = useState(false)
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null)

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`])
  }

  useEffect(() => {
    if (dataset) {
      const configs: FeatureConfig[] = dataset.columnInfo
        .filter((col: any) => col.name !== dataset.targetColumn)
        .map((col: any) => ({
          column: col.name,
          imputationStrategy: col.missing > 0 ? "mean" : "none",
          encoding: col.type === "categorical" ? "onehot" : "none",
          scaling: col.type === "numeric" ? "standard" : "none",
          transform: "none",
        }))

      setFeatureConfigs(configs)

      if (selectedFeatures.length === 0) {
        setSelectedFeatures(
          dataset.columnInfo.filter((col: any) => col.name !== dataset.targetColumn).map((col: any) => col.name),
        )
      }
    }
  }, [dataset])

  const toggleFeature = (feature: string) => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
    }

    debounceTimerRef.current = setTimeout(() => {
      if (selectedFeatures.includes(feature)) {
        setSelectedFeatures(selectedFeatures.filter((f) => f !== feature))
      } else {
        setSelectedFeatures([...selectedFeatures, feature])
      }
    }, 100)
  }

  const updateFeatureConfig = (column: string, field: keyof FeatureConfig, value: string) => {
    setFeatureConfigs(
      featureConfigs.map((config) => (config.column === column ? { ...config, [field]: value } : config)),
    )
  }

  const columnsWithMissing = dataset?.columnInfo.filter((col) => col.missing > 0) || []
  const totalMissing = columnsWithMissing.reduce((sum, col) => sum + col.missing, 0)
  const numericFeatures =
    dataset?.columnInfo.filter((col) => col.type === "numeric" && selectedFeatures.includes(col.name)) || []
  const categoricalFeatures =
    dataset?.columnInfo.filter((col) => col.type === "categorical" && selectedFeatures.includes(col.name)) || []

  const handleProcessFeatures = async () => {
    if (!dataset) return

    setIsProcessing(true)
    setLogs([])
    addLog("Starting feature engineering pipeline...")
    addLog(`Processing ${selectedFeatures.length} features for target: ${dataset.targetColumn}`)
    updatePipelineStep("feature", { status: "running", startTime: new Date().toISOString() })

    try {
      // Step 1: Handle missing values
      if (totalMissing > 0) {
        addLog(`\n--- MISSING VALUE IMPUTATION ---`)
        addLog(`Total missing cells: ${totalMissing.toLocaleString()}`)
        await new Promise((resolve) => setTimeout(resolve, 300))

        for (const col of columnsWithMissing) {
          if (!selectedFeatures.includes(col.name)) continue
          const config = featureConfigs.find((c) => c.column === col.name)
          const strategy = config?.imputationStrategy || "mean"

          addLog(`  ${col.name}: Imputing ${col.missing} values using ${strategy}`)

          if (strategy === "knn") {
            addLog(`    -> Using 5 nearest neighbors`)
          } else if (strategy === "iterative") {
            addLog(`    -> Running BayesianRidge regressor`)
          }
          await new Promise((resolve) => setTimeout(resolve, 150))
        }
        addLog(`Missing values handled successfully`)
      } else {
        addLog(`No missing values detected`)
      }

      // Step 2: Feature encoding
      if (categoricalFeatures.length > 0) {
        addLog(`\n--- CATEGORICAL ENCODING ---`)
        addLog(`Encoding ${categoricalFeatures.length} categorical features`)
        await new Promise((resolve) => setTimeout(resolve, 300))

        for (const col of categoricalFeatures) {
          const config = featureConfigs.find((c) => c.column === col.name)
          const encoding = config?.encoding || "onehot"

          if (encoding === "onehot") {
            addLog(`  ${col.name}: One-hot encoding (${col.unique} categories -> ${col.unique} columns)`)
          } else if (encoding === "target") {
            addLog(`  ${col.name}: Target encoding with smoothing (m=10)`)
          } else if (encoding === "label") {
            addLog(`  ${col.name}: Label encoding (0 to ${col.unique - 1})`)
          } else {
            addLog(`  ${col.name}: Frequency encoding`)
          }
          await new Promise((resolve) => setTimeout(resolve, 100))
        }
        addLog(`Feature encoding complete`)
      }

      // Step 3: Feature scaling
      if (numericFeatures.length > 0) {
        addLog(`\n--- FEATURE SCALING ---`)
        addLog(`Scaling ${numericFeatures.length} numeric features`)
        await new Promise((resolve) => setTimeout(resolve, 300))

        for (const col of numericFeatures) {
          const config = featureConfigs.find((c) => c.column === col.name)
          const scaling = config?.scaling || "standard"
          const transform = config?.transform || "none"

          if (transform !== "none") {
            addLog(`  ${col.name}: Applying ${transform} transform`)
          }

          if (scaling !== "none") {
            if (scaling === "standard") {
              addLog(`  ${col.name}: StandardScaler (mean=${col.stats?.mean || 0}, std=${col.stats?.std || 1})`)
            } else if (scaling === "minmax") {
              addLog(`  ${col.name}: MinMaxScaler [${col.stats?.min || 0}, ${col.stats?.max || 1}] -> [0, 1]`)
            } else if (scaling === "robust") {
              addLog(`  ${col.name}: RobustScaler (IQR: ${col.stats?.q25 || 0} - ${col.stats?.q75 || 1})`)
            }
          }
          await new Promise((resolve) => setTimeout(resolve, 80))
        }
        addLog(`Feature scaling complete`)
      }

      // Step 4: Class imbalance handling
      addLog(`\n--- CLASS IMBALANCE HANDLING ---`)
      addLog(`Checking class distribution for target: ${dataset.targetColumn}`)
      await new Promise((resolve) => setTimeout(resolve, 300))

      const targetCol = dataset.columnInfo.find((c) => c.name === dataset.targetColumn)
      addLog(`  Classes detected: ${targetCol?.unique || 2}`)

      // Placeholder for imbalance handling logic
      addLog(`  Skipping imbalance handling (using original distribution)`)

      await new Promise((resolve) => setTimeout(resolve, 400))

      // Step 5: Feature selection summary
      addLog(`\n--- FEATURE ENGINEERING SUMMARY ---`)
      addLog(`Input features: ${selectedFeatures.length}`)
      addLog(`Numeric features: ${numericFeatures.length}`)
      addLog(`Categorical features: ${categoricalFeatures.length}`)

      const totalOutputFeatures =
        numericFeatures.length +
        categoricalFeatures.reduce((sum, col) => {
          const config = featureConfigs.find((c) => c.column === col.name)
          return sum + (config?.encoding === "onehot" ? col.unique : 1)
        }, 0)
      addLog(`Output features (after encoding): ~${totalOutputFeatures}`)

      addLog(`\nFeature engineering pipeline complete!`)

      updatePipelineStep("feature", {
        status: "completed",
        endTime: new Date().toISOString(),
        logs,
      })
      setCurrentStep(2)

      toast({
        title: "Feature engineering complete",
        description: "Ready to generate EDA report",
      })

      await new Promise((resolve) => setTimeout(resolve, 500))
      router.push("/eda")
    } catch (error) {
      addLog(`ERROR: ${error instanceof Error ? error.message : "Processing failed"}`)
      updatePipelineStep("feature", { status: "failed" })
      toast({
        title: "Processing failed",
        description: error instanceof Error ? error.message : "Feature engineering failed",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  if (!dataset) {
    return (
      <div className="min-h-screen bg-background">
        <Sidebar />
        <main className="ml-64">
          <Header title="Feature Engineering" description="Handle missing values and class imbalance" />
          <div className="flex min-h-[60vh] items-center justify-center p-6">
            <Card className="max-w-md border-border bg-card">
              <CardContent className="pt-6 text-center">
                <AlertTriangle className="mx-auto h-12 w-12 text-yellow-400" />
                <h3 className="mt-4 text-lg font-semibold text-foreground">No Dataset Found</h3>
                <p className="mt-2 text-muted-foreground">
                  Please upload a dataset first to proceed with feature engineering.
                </p>
                <Button className="mt-4" onClick={() => router.push("/upload")}>
                  Upload Dataset
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header
          title="Feature Engineering"
          description={`Configure transformations for ${dataset.columns - 1} features | Target: ${dataset.targetColumn}`}
        />
        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="bg-secondary border border-border">
              <TabsTrigger value="selection" className="gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Feature Selection
              </TabsTrigger>
              <TabsTrigger value="imputation" className="gap-2">
                <Trash2 className="h-4 w-4" />
                Missing Values
              </TabsTrigger>
              <TabsTrigger value="encoding" className="gap-2">
                <Wand2 className="h-4 w-4" />
                Encoding & Scaling
              </TabsTrigger>
              <TabsTrigger value="imbalance" className="gap-2">
                <Scale className="h-4 w-4" />
                Class Imbalance
              </TabsTrigger>
            </TabsList>

            {/* Feature Selection Tab */}
            <TabsContent value="selection">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-foreground">
                    <Sparkles className="h-5 w-5 text-primary" />
                    Select Features for Training
                  </CardTitle>
                  <CardDescription>
                    Choose which columns to include as input features. Target column ({dataset.targetColumn}) is
                    excluded.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {selectedFeatures.length} of {dataset.columnInfo.length - 1} features selected
                    </span>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          setSelectedFeatures(
                            dataset.columnInfo
                              .filter((col: any) => col.name !== dataset.targetColumn)
                              .map((col: any) => col.name),
                          )
                        }
                      >
                        Select All
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setSelectedFeatures([])}>
                        Clear All
                      </Button>
                    </div>
                  </div>

                  <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                    {dataset.columnInfo
                      .filter((col: any) => col.name !== dataset.targetColumn)
                      .map((col: any) => (
                        <button
                          key={col.name}
                          onClick={() => toggleFeature(col.name)}
                          className={`flex cursor-pointer items-center justify-between rounded-lg border p-3 transition-all text-left ${
                            selectedFeatures.includes(col.name)
                              ? "border-primary/50 bg-primary/5"
                              : "border-border bg-secondary/30 hover:border-primary/30"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Checkbox
                              checked={selectedFeatures.includes(col.name)}
                              onCheckedChange={() => toggleFeature(col.name)}
                              className="pointer-events-none"
                            />
                            <div>
                              <div className="flex items-center gap-2">
                                {getTypeIcon(col.type)}
                                <span className="font-medium text-foreground text-sm truncate max-w-[120px]">
                                  {col.name}
                                </span>
                              </div>
                              <div className="flex gap-2 mt-1">
                                <Badge variant="outline" className="text-xs py-0">
                                  {col.type}
                                </Badge>
                                {col.missing > 0 && (
                                  <Badge
                                    variant="outline"
                                    className="text-xs py-0 bg-yellow-500/10 text-yellow-400 border-yellow-500/30"
                                  >
                                    {col.missing} null
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </button>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Missing Values Tab */}
            <TabsContent value="imputation">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-foreground">
                    <Trash2 className="h-5 w-5 text-yellow-400" />
                    Missing Value Imputation
                  </CardTitle>
                  <CardDescription>
                    Configure how to handle missing values for each column.
                    {totalMissing > 0
                      ? ` Found ${totalMissing.toLocaleString()} missing values in ${columnsWithMissing.length} columns.`
                      : " No missing values detected in your dataset."}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {totalMissing === 0 ? (
                    <div className="flex items-center gap-2 text-green-400 p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                      <CheckCircle2 className="h-5 w-5" />
                      <span>No missing values detected in selected features</span>
                    </div>
                  ) : (
                    <Accordion type="single" collapsible className="space-y-2">
                      {columnsWithMissing
                        .filter((col) => selectedFeatures.includes(col.name))
                        .map((col) => {
                          const config = featureConfigs.find((c) => c.column === col.name)
                          const strategies =
                            col.type === "numeric" ? imputationStrategies.numeric : imputationStrategies.categorical
                          return (
                            <AccordionItem key={col.name} value={col.name} className="border border-border rounded-lg">
                              <AccordionTrigger className="px-4 hover:no-underline">
                                <div className="flex items-center gap-3">
                                  <div className="text-left">
                                    <p className="font-medium text-foreground">{col.name}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {col.missing} missing ({((col.missing / (dataset?.rows || 1)) * 100).toFixed(1)}%)
                                    </p>
                                  </div>
                                </div>
                              </AccordionTrigger>
                              <AccordionContent className="pt-4 px-4 space-y-3">
                                <RadioGroup
                                  value={config?.imputationStrategy || "mean"}
                                  onValueChange={(val) => updateFeatureConfig(col.name, "imputationStrategy", val)}
                                >
                                  {strategies.map((strategy) => (
                                    <div
                                      key={strategy.value}
                                      className="flex items-center space-x-3 p-2 rounded hover:bg-secondary/30"
                                    >
                                      <RadioGroupItem value={strategy.value} id={`${col.name}-${strategy.value}`} />
                                      <label
                                        htmlFor={`${col.name}-${strategy.value}`}
                                        className="flex-1 cursor-pointer"
                                      >
                                        <p className="font-medium text-sm text-foreground">{strategy.label}</p>
                                        <p className="text-xs text-muted-foreground">{strategy.description}</p>
                                      </label>
                                    </div>
                                  ))}
                                </RadioGroup>
                              </AccordionContent>
                            </AccordionItem>
                          )
                        })}
                    </Accordion>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Encoding & Scaling Tab */}
            <TabsContent value="encoding">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-foreground">
                    <Wand2 className="h-5 w-5 text-primary" />
                    Encoding & Scaling Configuration
                  </CardTitle>
                  <CardDescription>
                    Configure encoding for categorical features and scaling for numeric features
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="space-y-2">
                    {dataset.columnInfo
                      .filter((col) => selectedFeatures.includes(col.name))
                      .map((col) => {
                        const config = featureConfigs.find((c) => c.column === col.name)
                        return (
                          <AccordionItem key={col.name} value={col.name} className="border border-border rounded-lg">
                            <AccordionTrigger className="px-4 hover:no-underline">
                              <div className="flex items-center gap-2">
                                {getTypeIcon(col.type)}
                                <span className="font-medium text-foreground">{col.name}</span>
                                <Badge variant="outline" className="ml-2 text-xs">
                                  {col.type}
                                </Badge>
                              </div>
                            </AccordionTrigger>
                            <AccordionContent className="pt-4 px-4 space-y-4">
                              {col.type === "categorical" && (
                                <div className="space-y-2">
                                  <Label className="font-medium">Encoding Strategy</Label>
                                  <Select
                                    value={config?.encoding || "onehot"}
                                    onValueChange={(val) => updateFeatureConfig(col.name, "encoding", val)}
                                  >
                                    <SelectTrigger className="bg-secondary border-border">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {encodingStrategies.map((strategy) => (
                                        <SelectItem key={strategy.value} value={strategy.value}>
                                          <div>
                                            <p className="font-medium">{strategy.label}</p>
                                            <p className="text-xs text-muted-foreground">{strategy.description}</p>
                                          </div>
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              )}

                              {col.type === "numeric" && (
                                <>
                                  <div className="space-y-2">
                                    <Label className="font-medium">Scaling Strategy</Label>
                                    <Select
                                      value={config?.scaling || "standard"}
                                      onValueChange={(val) => updateFeatureConfig(col.name, "scaling", val)}
                                    >
                                      <SelectTrigger className="bg-secondary border-border">
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {scalingStrategies.map((strategy) => (
                                          <SelectItem key={strategy.value} value={strategy.value}>
                                            <div>
                                              <p className="font-medium">{strategy.label}</p>
                                              <p className="text-xs text-muted-foreground">{strategy.description}</p>
                                            </div>
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>

                                  <div className="space-y-2">
                                    <Label className="font-medium">Transform Strategy</Label>
                                    <Select
                                      value={config?.transform || "none"}
                                      onValueChange={(val) => updateFeatureConfig(col.name, "transform", val)}
                                    >
                                      <SelectTrigger className="bg-secondary border-border">
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {transformStrategies.map((strategy) => (
                                          <SelectItem key={strategy.value} value={strategy.value}>
                                            <div>
                                              <p className="font-medium">{strategy.label}</p>
                                              <p className="text-xs text-muted-foreground">{strategy.description}</p>
                                            </div>
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>
                                </>
                              )}
                            </AccordionContent>
                          </AccordionItem>
                        )
                      })}
                  </Accordion>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="imbalance">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-foreground">
                    <Scale className="h-5 w-5 text-primary" />
                    Class Imbalance Handling
                  </CardTitle>
                  <CardDescription>Choose how to handle class imbalance in your target variable</CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Placeholder for class imbalance handling UI */}
                  <div className="flex items-center gap-2 text-muted-foreground p-4 rounded-lg bg-background border border-border">
                    <Settings2 className="h-5 w-5" />
                    <span>Class imbalance handling is not yet implemented.</span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Process Button */}
          <div className="mt-6 flex justify-end">
            <Button onClick={handleProcessFeatures} disabled={isProcessing} size="lg" className="gap-2">
              {isProcessing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Process & Continue to EDA
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </div>

          {/* Logs */}
          {logs.length > 0 && (
            <div className="mt-6">
              <LogViewer logs={logs} maxHeight="300px" />
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

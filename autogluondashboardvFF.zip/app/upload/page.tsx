"use client"

import type React from "react"
import { useState, useCallback } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { LogViewer } from "@/components/ui/log-viewer"
import { useMLStore, type ColumnInfo } from "@/lib/ml-store"
import { calculateStatistics } from "@/lib/ml-utils"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { generateSmartFeatureConfigs } from "@/lib/ml-preprocessing-defaults"
import {
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Database,
  Hash,
  Type,
  Calendar,
  Binary,
  ArrowRight,
  Cloud,
  Loader2,
  Info,
} from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Input } from "@/components/ui/input"

function getTypeIcon(type: string) {
  switch (type) {
    case "numeric":
      return <Hash className="h-4 w-4 text-blue-400" />
    case "categorical":
      return <Type className="h-4 w-4 text-green-400" />
    case "datetime":
      return <Calendar className="h-4 w-4 text-yellow-400" />
    case "boolean":
      return <Binary className="h-4 w-4 text-purple-400" />
    default:
      return <Type className="h-4 w-4 text-muted-foreground" />
  }
}

function getTypeBadgeColor(type: string) {
  switch (type) {
    case "numeric":
      return "bg-blue-500/20 text-blue-400 border-blue-500/30"
    case "categorical":
      return "bg-green-500/20 text-green-400 border-green-500/30"
    case "datetime":
      return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
    case "boolean":
      return "bg-purple-500/20 text-purple-400 border-purple-500/30"
    default:
      return "bg-muted text-muted-foreground"
  }
}

export default function UploadPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { dataset, setDataset, updatePipelineStep, setCurrentStep, setSelectedFeatures, setFeatureConfigs } =
    useMLStore()

  const [isDragging, setIsDragging] = useState(false)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [logs, setLogs] = useState<string[]>([])
  const [columns, setColumns] = useState<ColumnInfo[]>([])
  const [targetColumn, setTargetColumn] = useState<string>("")
  const [fileName, setFileName] = useState("")
  const [previewData, setPreviewData] = useState<string[][]>([])
  const [uploadProgress, setUploadProgress] = useState(0)
  const [searchQuery, setSearchQuery] = useState("")

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`])
  }

  const detectColumnType = (values: string[]): ColumnInfo["type"] => {
    const nonEmpty = values.filter((v) => v && v.trim() !== "")
    if (nonEmpty.length === 0) return "text"

    const numericCount = nonEmpty.filter((v) => !isNaN(Number(v))).length
    const booleanValues = ["true", "false", "yes", "no", "1", "0"]
    const booleanCount = nonEmpty.filter((v) => booleanValues.includes(v.toLowerCase())).length
    const dateCount = nonEmpty.filter((v) => !isNaN(Date.parse(v)) && v.includes("-")).length

    if (booleanCount === nonEmpty.length) return "boolean"
    if (numericCount > nonEmpty.length * 0.8) return "numeric"
    if (dateCount > nonEmpty.length * 0.8) return "datetime"

    const uniqueRatio = new Set(nonEmpty).size / nonEmpty.length
    if (uniqueRatio < 0.5) return "categorical"

    return "text"
  }

  const parseCSVStreaming = (text: string, onProgress: (progress: number) => void): string[][] => {
    const lines = text.split("\n").filter((line) => line.trim())
    const result: string[][] = []
    const totalLines = lines.length

    for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
      const line = lines[lineIdx]
      const parsed: string[] = []
      let current = ""
      let inQuotes = false

      for (let i = 0; i < line.length; i++) {
        const char = line[i]
        if (char === '"') {
          inQuotes = !inQuotes
        } else if (char === "," && !inQuotes) {
          parsed.push(current.trim())
          current = ""
        } else {
          current += char
        }
      }
      parsed.push(current.trim())
      result.push(parsed)

      // Update progress every 1000 lines
      if (lineIdx % 1000 === 0) {
        onProgress(Math.round((lineIdx / totalLines) * 100))
      }
    }

    onProgress(100)
    return result
  }

  const analyzeFile = async (file: File) => {
    setIsAnalyzing(true)
    addLog("Starting file analysis...")
    updatePipelineStep("upload", { status: "running", startTime: new Date().toISOString() })

    try {
      addLog(`File size: ${(file.size / 1024 / 1024).toFixed(2)} MB`)
      const text = await file.text()

      const data = parseCSVStreaming(text, (progress) => {
        setUploadProgress(progress)
        if (progress % 20 === 0) {
          addLog(`Parsing progress: ${progress}%`)
        }
      })
      setUploadProgress(0)

      if (data.length < 2) {
        throw new Error("CSV must have at least a header row and one data row")
      }

      const headers = data[0]
      const rows = data.slice(1)
      setPreviewData(data.slice(0, 6)) // First 5 rows + header for preview

      addLog(`Parsed ${rows.length.toLocaleString()} rows and ${headers.length} columns`)
      addLog("Detecting column types and computing statistics...")

      const columnInfo: ColumnInfo[] = []
      const batchSize = 10

      for (let i = 0; i < headers.length; i += batchSize) {
        const batch = headers.slice(i, Math.min(i + batchSize, headers.length))

        const batchInfo = batch.map((header) => {
          const index = headers.indexOf(header)
          const columnValues = rows.map((row) => row[index] || "")
          const type = detectColumnType(columnValues)
          const missing = columnValues.filter((v) => !v || v.trim() === "").length
          const unique = new Set(columnValues.filter((v) => v && v.trim())).size
          const stats = calculateStatistics(columnValues, type)

          addLog(`  Column "${header}": ${type} | ${missing} missing | ${unique} unique values`)

          return {
            name: header,
            type,
            missing,
            unique,
            sample: columnValues.slice(0, 3),
            stats,
          }
        })

        columnInfo.push(...batchInfo)

        // Allow UI to update between batches
        await new Promise((resolve) => setTimeout(resolve, 10))
      }

      setColumns(columnInfo)
      addLog(`Column analysis complete`)
      addLog("Simulating AWS S3 upload...")

      await new Promise((resolve) => setTimeout(resolve, 800))
      addLog(`File uploaded to S3: s3://autogluon-data/${file.name}`)

      setDataset({
        fileName: file.name,
        rows: rows.length,
        columns: headers.length,
        columnInfo,
        targetColumn: null,
        uploadedAt: new Date().toISOString(),
        s3Url: `s3://autogluon-data/${file.name}`,
        rawData: data,
      })

      toast({
        title: "File analyzed successfully",
        description: `Detected ${columnInfo.length} columns from ${rows.length.toLocaleString()} rows`,
      })
    } catch (error) {
      addLog(`ERROR: ${error instanceof Error ? error.message : "Failed to analyze file"}`)
      updatePipelineStep("upload", { status: "failed" })
      toast({
        title: "Analysis failed",
        description: error instanceof Error ? error.message : "Failed to analyze file",
        variant: "destructive",
      })
    } finally {
      setIsAnalyzing(false)
      setUploadProgress(0)
    }
  }

  const handleFileSelect = useCallback(async (file: File) => {
    if (!file.name.endsWith(".csv")) {
      toast({
        title: "Invalid file type",
        description: "Please upload a CSV file",
        variant: "destructive",
      })
      return
    }

    setFileName(file.name)
    setLogs([])
    setTargetColumn("")
    addLog(`Selected file: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`)
    await analyzeFile(file)
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault()
      setIsDragging(false)
      const file = e.dataTransfer.files[0]
      if (file) handleFileSelect(file)
    },
    [handleFileSelect],
  )

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file) handleFileSelect(file)
    },
    [handleFileSelect],
  )

  const handleConfirmAndContinue = () => {
    if (!targetColumn) {
      toast({
        title: "Select target column",
        description: "Please select a target column for prediction",
        variant: "destructive",
      })
      return
    }

    const updatedDataset = {
      ...dataset!,
      targetColumn,
    }
    setDataset(updatedDataset)

    // Initialize feature configs for each column
    const featureColumns = columns.filter((col) => col.name !== targetColumn)
    setSelectedFeatures(featureColumns.map((col) => col.name))

    const smartConfigs = generateSmartFeatureConfigs(columns, targetColumn)
    setFeatureConfigs(smartConfigs)

    updatePipelineStep("upload", {
      status: "completed",
      endTime: new Date().toISOString(),
      logs,
    })
    setCurrentStep(1)

    toast({
      title: "Upload complete",
      description: "Proceeding to feature engineering with smart defaults",
    })

    router.push("/features")
  }

  const filteredColumns = columns.filter((col) => col.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header title="Upload Dataset" description="Upload your CSV file and detect column types automatically" />
        <div className="p-6">
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Upload Area */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Cloud className="h-5 w-5 text-primary" />
                  Upload to AWS S3
                </CardTitle>
                <CardDescription>Drag and drop your CSV file or click to browse</CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  className={`relative flex min-h-[200px] cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed transition-all ${
                    isDragging
                      ? "border-primary bg-primary/10"
                      : "border-border bg-secondary/30 hover:border-primary/50 hover:bg-secondary/50"
                  }`}
                >
                  <input
                    type="file"
                    accept=".csv"
                    onChange={handleInputChange}
                    className="absolute inset-0 cursor-pointer opacity-0"
                    disabled={isAnalyzing}
                  />
                  {isAnalyzing ? (
                    <div className="flex flex-col items-center gap-4">
                      <Loader2 className="h-12 w-12 animate-spin text-primary" />
                      <p className="text-muted-foreground">Analyzing file...</p>
                      {uploadProgress > 0 && <p className="text-sm text-primary">{uploadProgress}% complete</p>}
                    </div>
                  ) : fileName ? (
                    <div className="flex flex-col items-center gap-4">
                      <div className="rounded-full bg-green-500/20 p-4">
                        <FileSpreadsheet className="h-10 w-10 text-green-400" />
                      </div>
                      <div className="text-center">
                        <p className="font-medium text-foreground">{fileName}</p>
                        <p className="text-sm text-muted-foreground">Click or drag to replace</p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-4">
                      <div className="rounded-full bg-primary/20 p-4">
                        <Upload className="h-10 w-10 text-primary" />
                      </div>
                      <div className="text-center">
                        <p className="font-medium text-foreground">Drop your CSV file here</p>
                        <p className="text-sm text-muted-foreground">or click to browse files</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Data Preview */}
                {previewData.length > 0 && (
                  <div className="mt-6">
                    <Label className="text-muted-foreground">Data Preview (First 5 rows)</Label>
                    <div className="mt-2 max-h-[200px] overflow-auto rounded-lg border border-border">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-border hover:bg-transparent">
                            {previewData[0]?.map((header, i) => (
                              <TableHead key={i} className="text-muted-foreground whitespace-nowrap text-xs">
                                {header}
                              </TableHead>
                            ))}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {previewData.slice(1).map((row, i) => (
                            <TableRow key={i} className="border-border">
                              {row.map((cell, j) => (
                                <TableCell key={j} className="text-xs py-1.5 whitespace-nowrap">
                                  {cell || <span className="text-muted-foreground/50">null</span>}
                                </TableCell>
                              ))}
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}

                {logs.length > 0 && (
                  <div className="mt-6">
                    <Label className="text-muted-foreground">Processing Logs</Label>
                    <LogViewer logs={logs} className="mt-2" maxHeight="150px" />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Column Detection */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Database className="h-5 w-5 text-primary" />
                  Detected Columns ({columns.length})
                </CardTitle>
                <CardDescription>Review detected column types and select target variable</CardDescription>
              </CardHeader>
              <CardContent>
                {columns.length === 0 ? (
                  <div className="flex min-h-[300px] flex-col items-center justify-center rounded-xl border border-dashed border-border bg-secondary/20">
                    <Database className="h-12 w-12 text-muted-foreground/50" />
                    <p className="mt-4 text-muted-foreground">Upload a CSV to detect columns</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Target Selection with Searchable Dropdown */}
                    <div className="rounded-lg bg-primary/5 border border-primary/20 p-4">
                      <Label className="text-foreground font-medium">Target Column (for prediction)</Label>
                      <div className="mt-2 space-y-2">
                        <Input
                          placeholder="Search columns..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="bg-secondary border-border"
                        />
                        <div className="relative">
                          <Select value={targetColumn} onValueChange={setTargetColumn}>
                            <SelectTrigger className="bg-secondary border-border">
                              <SelectValue placeholder="Select target column" />
                            </SelectTrigger>
                            <SelectContent className="max-h-[300px]">
                              {filteredColumns.length > 0 ? (
                                filteredColumns.map((col) => (
                                  <SelectItem key={col.name} value={col.name}>
                                    <div className="flex items-center gap-2">
                                      {getTypeIcon(col.type)}
                                      <span>{col.name}</span>
                                      <span className="text-muted-foreground text-xs">({col.unique} classes)</span>
                                    </div>
                                  </SelectItem>
                                ))
                              ) : (
                                <div className="px-2 py-1.5 text-sm text-muted-foreground">No columns found</div>
                              )}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Columns Table */}
                    <div className="max-h-[350px] overflow-auto rounded-lg border border-border">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-border hover:bg-transparent">
                            <TableHead className="text-muted-foreground">Column Name</TableHead>
                            <TableHead className="text-muted-foreground">Type</TableHead>
                            <TableHead className="text-muted-foreground">Missing</TableHead>
                            <TableHead className="text-muted-foreground">Stats</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {columns.map((col) => (
                            <TableRow
                              key={col.name}
                              className={`border-border ${col.name === targetColumn ? "bg-primary/10" : ""}`}
                            >
                              <TableCell className="font-medium text-foreground">
                                <div className="flex items-center gap-2">
                                  {col.name === targetColumn && <CheckCircle2 className="h-4 w-4 text-primary" />}
                                  <span className="truncate max-w-[150px]">{col.name}</span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className={getTypeBadgeColor(col.type)}>
                                  <span className="flex items-center gap-1.5">
                                    {getTypeIcon(col.type)}
                                    {col.type}
                                  </span>
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {col.missing > 0 ? (
                                  <span className="flex items-center gap-1 text-yellow-400">
                                    <AlertCircle className="h-3 w-3" />
                                    {col.missing} ({((col.missing / (dataset?.rows || 1)) * 100).toFixed(1)}%)
                                  </span>
                                ) : (
                                  <span className="text-green-400">0</span>
                                )}
                              </TableCell>
                              <TableCell>
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger>
                                      <Info className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                                    </TooltipTrigger>
                                    <TooltipContent className="max-w-[250px]">
                                      {col.type === "numeric" && col.stats ? (
                                        <div className="text-xs space-y-1">
                                          <p>Mean: {col.stats.mean}</p>
                                          <p>Std: {col.stats.std}</p>
                                          <p>
                                            Min: {col.stats.min} | Max: {col.stats.max}
                                          </p>
                                          <p>
                                            Q25: {col.stats.q25} | Q75: {col.stats.q75}
                                          </p>
                                        </div>
                                      ) : (
                                        <div className="text-xs space-y-1">
                                          <p>Unique: {col.unique}</p>
                                          <p>
                                            Mode: {col.stats?.mode} ({col.stats?.topValues?.[0]?.count || 0}{" "}
                                            occurrences)
                                          </p>
                                        </div>
                                      )}
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>

                    {/* Continue Button */}
                    <Button
                      onClick={handleConfirmAndContinue}
                      disabled={!targetColumn}
                      size="lg"
                      className="w-full gap-2"
                    >
                      Confirm & Continue
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

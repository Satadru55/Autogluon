"use client"

import { useState } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Bell, CheckCircle, AlertCircle, Info, Trash2, Clock } from "lucide-react"

interface Notification {
  id: string
  type: "success" | "error" | "info" | "warning"
  title: string
  message: string
  timestamp: Date
  read: boolean
  action?: {
    label: string
    href: string
  }
}

const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "success",
    title: "EDA Report Completed",
    message: "Your exploratory data analysis report has been generated successfully.",
    timestamp: new Date(Date.now() - 5 * 60000),
    read: false,
    action: { label: "View Report", href: "/eda" },
  },
  {
    id: "2",
    type: "success",
    title: "Model Training Finished",
    message: "AutoGluon has completed training 5 models with best score of 0.92 AUC.",
    timestamp: new Date(Date.now() - 15 * 60000),
    read: false,
    action: { label: "View Results", href: "/training" },
  },
  {
    id: "3",
    type: "info",
    title: "Dataset Uploaded",
    message: "Your dataset 'customer_data.csv' with 50,000 rows has been uploaded successfully.",
    timestamp: new Date(Date.now() - 1 * 3600000),
    read: true,
  },
  {
    id: "4",
    type: "warning",
    title: "High Missing Values Detected",
    message: "Column 'phone_number' has 35% missing values. Consider imputation or removal.",
    timestamp: new Date(Date.now() - 2 * 3600000),
    read: true,
  },
  {
    id: "5",
    type: "info",
    title: "Feature Engineering Complete",
    message: "12 new features were created and added to your dataset.",
    timestamp: new Date(Date.now() - 4 * 3600000),
    read: true,
  },
]

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications)
  const [filter, setFilter] = useState<"all" | "unread" | "success" | "error" | "warning" | "info">("all")

  const filteredNotifications = notifications.filter((n) => {
    if (filter === "all") return true
    if (filter === "unread") return !n.read
    return n.type === filter
  })

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id))
  }

  const deleteAll = () => {
    setNotifications([])
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-400" />
      case "error":
        return <AlertCircle className="h-5 w-5 text-red-400" />
      case "warning":
        return <AlertCircle className="h-5 w-5 text-yellow-400" />
      default:
        return <Info className="h-5 w-5 text-blue-400" />
    }
  }

  const formatTime = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 1) return "Just now"
    if (minutes < 60) return `${minutes}m ago`
    if (hours < 24) return `${hours}h ago`
    if (days < 7) return `${days}d ago`
    return date.toLocaleDateString()
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header
          title="Notifications"
          description={`You have ${unreadCount} unread notification${unreadCount !== 1 ? "s" : ""}`}
        />
        <div className="space-y-4 p-6">
          {/* Filter and Actions */}
          <div className="flex flex-wrap items-center gap-3">
            <Button
              variant={filter === "all" ? "default" : "outline"}
              onClick={() => setFilter("all")}
              className="gap-2"
            >
              All ({notifications.length})
            </Button>
            <Button
              variant={filter === "unread" ? "default" : "outline"}
              onClick={() => setFilter("unread")}
              className="gap-2"
            >
              Unread ({unreadCount})
            </Button>
            <Button
              variant={filter === "success" ? "default" : "outline"}
              onClick={() => setFilter("success")}
              className="gap-2"
            >
              Success
            </Button>
            <Button
              variant={filter === "warning" ? "default" : "outline"}
              onClick={() => setFilter("warning")}
              className="gap-2"
            >
              Warnings
            </Button>

            <div className="ml-auto flex gap-2">
              {unreadCount > 0 && (
                <Button onClick={markAllAsRead} variant="outline" size="sm" className="gap-1 bg-transparent">
                  <CheckCircle className="h-4 w-4" />
                  Mark All as Read
                </Button>
              )}
              {notifications.length > 0 && (
                <Button onClick={deleteAll} variant="outline" size="sm" className="gap-1 text-red-400 bg-transparent">
                  <Trash2 className="h-4 w-4" />
                  Clear All
                </Button>
              )}
            </div>
          </div>

          {/* Notifications List */}
          {filteredNotifications.length === 0 ? (
            <Card className="border-border bg-card">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Bell className="h-12 w-12 text-muted-foreground/50" />
                <h3 className="mt-4 text-lg font-semibold text-foreground">No Notifications</h3>
                <p className="mt-2 text-muted-foreground">All caught up! You have no notifications to display.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {filteredNotifications.map((notification) => (
                <Card
                  key={notification.id}
                  className={`border-border transition-all ${notification.read ? "bg-card" : "border-primary/50 bg-primary/5"}`}
                >
                  <CardContent className="flex items-start gap-4 p-4">
                    <div className="mt-1">{getIcon(notification.type)}</div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-foreground">{notification.title}</h4>
                            {!notification.read && <Badge className="h-2 w-2 rounded-full" variant="default" />}
                          </div>
                          <p className="mt-1 text-sm text-muted-foreground">{notification.message}</p>
                          <p className="mt-2 flex items-center gap-1 text-xs text-muted-foreground/75">
                            <Clock className="h-3 w-3" />
                            {formatTime(notification.timestamp)}
                          </p>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="mt-3 flex flex-wrap items-center gap-2">
                        {notification.action && (
                          <Button
                            href={notification.action.href}
                            variant="outline"
                            size="sm"
                            className="text-xs bg-transparent"
                          >
                            {notification.action.label}
                          </Button>
                        )}
                        {!notification.read && (
                          <Button
                            onClick={() => markAsRead(notification.id)}
                            variant="ghost"
                            size="sm"
                            className="text-xs"
                          >
                            Mark as Read
                          </Button>
                        )}
                        <Button
                          onClick={() => deleteNotification(notification.id)}
                          variant="ghost"
                          size="sm"
                          className="ml-auto text-xs text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

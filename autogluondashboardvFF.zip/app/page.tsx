"use client"

import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { MetricCard } from "@/components/ui/metric-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useMLStore } from "@/lib/ml-store"
import Link from "next/link"
import {
  Upload,
  Database,
  Brain,
  Rocket,
  ArrowRight,
  CheckCircle2,
  Circle,
  Loader2,
  XCircle,
  Sparkles,
  BarChart3,
  Layers,
  Wand2,
  Zap,
} from "lucide-react"

const pipelineStepsInfo = [
  {
    id: "upload",
    title: "Upload Dataset",
    description: "Upload CSV to AWS S3 and detect column types",
    icon: Upload,
    href: "/upload",
  },
  {
    id: "feature",
    title: "Feature Engineering",
    description: "Handle missing values and class imbalance",
    icon: Sparkles,
    href: "/features",
  },
  {
    id: "eda",
    title: "EDA Report",
    description: "Generate exploratory data analysis report",
    icon: BarChart3,
    href: "/eda",
  },
  {
    id: "preprocessing",
    title: "Data Preprocessing",
    description: "Configure transformations, scaling, and encoding",
    icon: Wand2,
    href: "/preprocessing",
  },
  {
    id: "training",
    title: "Model Training",
    description: "Train RF, XGBoost, Neural Networks & more",
    icon: Brain,
    href: "/training",
  },
  {
    id: "ensemble",
    title: "Ensemble",
    description: "Create ensemble models for best performance",
    icon: Layers,
    href: "/ensemble",
  },
  {
    id: "predictions",
    title: "Test Predictions",
    description: "Make predictions on test set",
    icon: Zap,
    href: "/predictions",
  },
]

function getStepIcon(status: string) {
  switch (status) {
    case "completed":
      return <CheckCircle2 className="h-5 w-5 text-green-400" />
    case "running":
      return <Loader2 className="h-5 w-5 text-primary animate-spin" />
    case "failed":
      return <XCircle className="h-5 w-5 text-destructive" />
    default:
      return <Circle className="h-5 w-5 text-muted-foreground/50" />
  }
}

export default function HomePage() {
  const { dataset, pipelineSteps, modelResults, deploymentStatus } = useMLStore()

  const completedSteps = pipelineSteps.filter((s) => s.status === "completed").length
  const bestModel =
    modelResults.length > 0
      ? modelResults.reduce((best, current) => (current.accuracy > best.accuracy ? current : best))
      : null

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header title="Pipeline Overview" description="End-to-end AutoML pipeline for production-ready models" />
        <div className="p-6">
          {/* Hero Section */}
          <div className="mb-8 rounded-2xl bg-gradient-to-br from-primary/20 via-primary/5 to-transparent p-8">
            <div className="max-w-2xl">
              <h2 className="text-3xl font-bold text-foreground">Build Production ML Models</h2>
              <p className="mt-3 text-lg text-muted-foreground">
                Upload your dataset and let AutoGluon handle feature engineering, model training, hyperparameter tuning,
                and deployment automatically.
              </p>
              <Link href="/upload">
                <Button size="lg" className="mt-6 gap-2">
                  Get Started
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Metrics */}
          <div className="mb-8 grid gap-4 md:grid-cols-4">
            <MetricCard
              title="Dataset Status"
              value={dataset ? "Uploaded" : "No Data"}
              subtitle={dataset ? `${dataset.rows.toLocaleString()} rows` : "Upload CSV to start"}
              icon={Database}
            />
            <MetricCard
              title="Pipeline Progress"
              value={`${completedSteps}/${pipelineSteps.length}`}
              subtitle="Steps completed"
              icon={Rocket}
            />
            <MetricCard
              title="Best Model"
              value={bestModel ? `${(bestModel.accuracy * 100).toFixed(1)}%` : "—"}
              subtitle={bestModel ? bestModel.name : "Train models first"}
              icon={Brain}
            />
            <MetricCard
              title="Deployment"
              value={
                deploymentStatus === "deployed"
                  ? "Live"
                  : deploymentStatus === "deploying"
                    ? "In Progress"
                    : "Not Deployed"
              }
              subtitle={deploymentStatus === "deployed" ? "API ready" : "Deploy when ready"}
              icon={Rocket}
            />
          </div>

          {/* Pipeline Steps */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">ML Pipeline Steps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {pipelineStepsInfo.map((stepInfo) => {
                  const step = pipelineSteps.find((s) => s.id === stepInfo.id)
                  return (
                    <Link key={stepInfo.id} href={stepInfo.href}>
                      <Card className="group cursor-pointer border-border bg-secondary/30 transition-all hover:border-primary/50 hover:bg-secondary/50">
                        <CardContent className="p-5">
                          <div className="flex items-start justify-between">
                            <div className="rounded-lg bg-primary/10 p-2.5">
                              <stepInfo.icon className="h-5 w-5 text-primary" />
                            </div>
                            {step && getStepIcon(step.status)}
                          </div>
                          <h3 className="mt-4 font-semibold text-foreground group-hover:text-primary">
                            {stepInfo.title}
                          </h3>
                          <p className="mt-1 text-sm text-muted-foreground">{stepInfo.description}</p>
                        </CardContent>
                      </Card>
                    </Link>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

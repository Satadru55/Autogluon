"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useMLStore } from "@/lib/ml-store"
import { AlertCircle, ArrowRight, CheckCircle2, Loader2, Zap, ChevronDown, ChevronUp } from "lucide-react"
import {
  IMPUTATION_STRATEGIES,
  TRANSFORM_OPTIONS,
  SCALING_OPTIONS,
  ENCODING_OPTIONS,
  preprocessingSteps,
  generatePreprocessingReport,
} from "@/lib/preprocessing-utils"
import type { PreprocessingConfig, NumericFeatureConfig, CategoricalFeatureConfig } from "@/lib/preprocessing-utils"

export default function PreprocessingPage() {
  const router = useRouter()
  const { dataset, edaResults, updatePipelineStep, setCurrentStep, selectedFeatures } = useMLStore()
  const [isProcessing, setIsProcessing] = useState(false)
  const [currentPhase, setCurrentPhase] = useState(0)
  const [phases, setPhases] = useState<Array<any>>([])
  const [showReport, setShowReport] = useState(false)
  const [report, setReport] = useState("")

  const [config, setConfig] = useState<PreprocessingConfig>(() => {
    if (!dataset) return { numericFeatures: [], categoricalFeatures: [], removeOutliers: true, outlierMethod: "iqr" }

    const numericFeatures: NumericFeatureConfig[] = dataset.columnInfo
      .filter(
        (col: any) =>
          col.type === "numeric" && col.name !== dataset.targetColumn && selectedFeatures.includes(col.name),
      )
      .map((col: any) => ({
        column: col.name,
        imputation: "median",
        transform: "none",
        scaling: "standard",
      }))

    const categoricalFeatures: CategoricalFeatureConfig[] = dataset.columnInfo
      .filter(
        (col: any) =>
          col.type === "categorical" && col.name !== dataset.targetColumn && selectedFeatures.includes(col.name),
      )
      .map((col: any) => ({
        column: col.name,
        imputation: "mode",
        encoding: "label",
      }))

    return {
      numericFeatures,
      categoricalFeatures,
      removeOutliers: true, // Default to true
      outlierMethod: "iqr",
    }
  })

  const [expandedNumeric, setExpandedNumeric] = useState<Set<string>>(new Set())
  const [expandedCategorical, setExpandedCategorical] = useState<Set<string>>(new Set())

  if (!dataset) {
    return (
      <div className="min-h-screen bg-background">
        <Sidebar />
        <main className="ml-64">
          <Header title="Data Preprocessing" description="Configure data transformations and scaling" />
          <div className="p-6">
            <Card className="border-destructive/50 bg-destructive/5">
              <CardContent className="flex items-center gap-3 pt-6">
                <AlertCircle className="h-5 w-5 text-destructive" />
                <p className="text-foreground">Please upload a dataset first.</p>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  const updateNumericFeature = (column: string, updates: Partial<NumericFeatureConfig>) => {
    setConfig((prev) => ({
      ...prev,
      numericFeatures: prev.numericFeatures.map((f) => (f.column === column ? { ...f, ...updates } : f)),
    }))
  }

  const updateCategoricalFeature = (column: string, updates: Partial<CategoricalFeatureConfig>) => {
    setConfig((prev) => ({
      ...prev,
      categoricalFeatures: prev.categoricalFeatures.map((f) => (f.column === column ? { ...f, ...updates } : f)),
    }))
  }

  const handleStartProcessing = async () => {
    setIsProcessing(true)
    setShowReport(false)
    const report = generatePreprocessingReport(config)
    setReport(report)

    const newPhases = preprocessingSteps(config)
    setPhases(newPhases)
    setCurrentPhase(0)

    updatePipelineStep("preprocessing", {
      status: "running",
      startTime: new Date().toISOString(),
    })

    for (let i = 0; i < newPhases.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 800 + Math.random() * 1200))

      setPhases((prev) =>
        prev.map((p, idx) => ({
          ...p,
          status: idx <= i ? "completed" : idx === i + 1 ? "running" : "pending",
        })),
      )
      setCurrentPhase(i + 1)
    }

    updatePipelineStep("preprocessing", {
      status: "completed",
      endTime: new Date().toISOString(),
      result: config,
    })

    setIsProcessing(false)
    setShowReport(true)
  }

  const handleContinue = () => {
    setCurrentStep(4)
    router.push("/training")
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header title="Data Preprocessing" description="Configure transformations for each feature individually" />
        <div className="space-y-6 p-6">
          {!isProcessing && !showReport && (
            <>
              {/* Numeric Features Section */}
              {config.numericFeatures.length > 0 && (
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-blue-500" />
                      Numeric Features ({config.numericFeatures.length})
                    </CardTitle>
                    <CardDescription>
                      Configure imputation, transformation, and scaling for each numeric column
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {config.numericFeatures.map((feature) => (
                      <div key={feature.column} className="border rounded-lg">
                        <button
                          onClick={() =>
                            setExpandedNumeric((prev) => {
                              const next = new Set(prev)
                              next.has(feature.column) ? next.delete(feature.column) : next.add(feature.column)
                              return next
                            })
                          }
                          className="w-full px-4 py-3 flex items-center justify-between hover:bg-secondary/50"
                        >
                          <span className="font-semibold text-foreground">{feature.column}</span>
                          {expandedNumeric.has(feature.column) ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </button>

                        {expandedNumeric.has(feature.column) && (
                          <div className="px-4 py-4 border-t space-y-4 bg-secondary/20">
                            {/* Imputation */}
                            <div className="space-y-2">
                              <Label className="text-sm font-semibold">Imputation</Label>
                              <Select
                                value={feature.imputation}
                                onValueChange={(value: any) =>
                                  updateNumericFeature(feature.column, { imputation: value })
                                }
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {IMPUTATION_STRATEGIES.numeric.map((opt) => (
                                    <SelectItem key={opt.id} value={opt.id}>
                                      {opt.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <p className="text-xs text-muted-foreground">
                                {IMPUTATION_STRATEGIES.numeric.find((o) => o.id === feature.imputation)?.description}
                              </p>
                            </div>

                            {/* Transformation */}
                            <div className="space-y-2">
                              <Label className="text-sm font-semibold">Transformation</Label>
                              <Select
                                value={feature.transform}
                                onValueChange={(value: any) =>
                                  updateNumericFeature(feature.column, { transform: value })
                                }
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {TRANSFORM_OPTIONS.map((opt) => (
                                    <SelectItem key={opt.id} value={opt.id}>
                                      {opt.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <p className="text-xs text-muted-foreground">
                                {TRANSFORM_OPTIONS.find((o) => o.id === feature.transform)?.description}
                              </p>
                            </div>

                            {/* Scaling */}
                            <div className="space-y-2">
                              <Label className="text-sm font-semibold">Scaling</Label>
                              <Select
                                value={feature.scaling}
                                onValueChange={(value: any) => updateNumericFeature(feature.column, { scaling: value })}
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {SCALING_OPTIONS.map((opt) => (
                                    <SelectItem key={opt.id} value={opt.id}>
                                      {opt.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <p className="text-xs text-muted-foreground">
                                {SCALING_OPTIONS.find((o) => o.id === feature.scaling)?.description}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Categorical Features Section */}
              {config.categoricalFeatures.length > 0 && (
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-purple-500" />
                      Categorical Features ({config.categoricalFeatures.length})
                    </CardTitle>
                    <CardDescription>Configure imputation and encoding for each categorical column</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {config.categoricalFeatures.map((feature) => (
                      <div key={feature.column} className="border rounded-lg">
                        <button
                          onClick={() =>
                            setExpandedCategorical((prev) => {
                              const next = new Set(prev)
                              next.has(feature.column) ? next.delete(feature.column) : next.add(feature.column)
                              return next
                            })
                          }
                          className="w-full px-4 py-3 flex items-center justify-between hover:bg-secondary/50"
                        >
                          <span className="font-semibold text-foreground">{feature.column}</span>
                          {expandedCategorical.has(feature.column) ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </button>

                        {expandedCategorical.has(feature.column) && (
                          <div className="px-4 py-4 border-t space-y-4 bg-secondary/20">
                            {/* Imputation */}
                            <div className="space-y-2">
                              <Label className="text-sm font-semibold">Imputation</Label>
                              <Select
                                value={feature.imputation}
                                onValueChange={(value: any) =>
                                  updateCategoricalFeature(feature.column, { imputation: value })
                                }
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {IMPUTATION_STRATEGIES.categorical.map((opt) => (
                                    <SelectItem key={opt.id} value={opt.id}>
                                      {opt.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <p className="text-xs text-muted-foreground">
                                {
                                  IMPUTATION_STRATEGIES.categorical.find((o) => o.id === feature.imputation)
                                    ?.description
                                }
                              </p>
                            </div>

                            {/* Encoding */}
                            <div className="space-y-2">
                              <Label className="text-sm font-semibold">Encoding</Label>
                              <Select
                                value={feature.encoding}
                                onValueChange={(value: any) =>
                                  updateCategoricalFeature(feature.column, { encoding: value })
                                }
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {ENCODING_OPTIONS.map((opt) => (
                                    <SelectItem key={opt.id} value={opt.id}>
                                      {opt.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <p className="text-xs text-muted-foreground">
                                {ENCODING_OPTIONS.find((o) => o.id === feature.encoding)?.description}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Outlier Handling Card */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>Outlier Handling</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="outliers"
                      checked={config.removeOutliers}
                      onCheckedChange={(checked) => setConfig({ ...config, removeOutliers: checked as boolean })}
                    />
                    <Label htmlFor="outliers" className="cursor-pointer font-medium">
                      Remove outliers
                    </Label>
                  </div>
                  {config.removeOutliers && (
                    <div className="ml-6 space-y-3">
                      <Label className="font-semibold text-foreground">Detection Method</Label>
                      <Select
                        value={config.outlierMethod}
                        onValueChange={(value: any) => setConfig({ ...config, outlierMethod: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="iqr">
                            <span>IQR Method</span>
                            <span className="text-xs text-muted-foreground ml-2">Values outside 1.5 × IQR range</span>
                          </SelectItem>
                          <SelectItem value="zscore">
                            <span>Z-Score Method</span>
                            <span className="text-xs text-muted-foreground ml-2">Values with |z-score| &gt; 3</span>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Start Button */}
              <div className="flex justify-end">
                <Button onClick={handleStartProcessing} size="lg" className="gap-2">
                  Start Preprocessing
                  <Zap className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}

          {/* Processing Progress */}
          {isProcessing && (
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  Processing Data
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {phases.map((phase, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-foreground">{phase.message}</span>
                      <span className="text-xs text-muted-foreground">
                        {phase.phase}/{phase.totalPhases}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 rounded-full bg-secondary h-2">
                        <div
                          className={`h-full rounded-full transition-all ${
                            phase.status === "completed"
                              ? "bg-green-500"
                              : phase.status === "running"
                                ? "bg-blue-500 animate-pulse"
                                : "bg-muted"
                          }`}
                          style={{
                            width: phase.status === "completed" ? "100%" : phase.status === "running" ? "70%" : "0%",
                          }}
                        />
                      </div>
                      {phase.status === "completed" && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Report Section */}
          {showReport && (
            <>
              <Card className="border-green-500/30 bg-green-500/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-600">
                    <CheckCircle2 className="h-5 w-5" />
                    Preprocessing Complete
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="overflow-auto rounded-lg bg-secondary/50 p-4 text-xs text-foreground font-mono max-h-96">
                    {report}
                  </pre>
                </CardContent>
              </Card>

              {/* Continue Button */}
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowReport(false)}>
                  Reconfigure
                </Button>
                <Button onClick={handleContinue} className="gap-2">
                  Continue to Model Training
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  )
}

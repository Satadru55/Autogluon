"use client"

import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Progress } from "@/components/ui/progress"
import { LogViewer } from "@/components/ui/log-viewer"
import { useMLStore } from "@/lib/ml-store"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { toast } from "@/hooks/use-toast"
import { ArrowRight, ArrowLeft, Wand2, Loader2, CheckCircle2 } from "lucide-react"

export default function TuningPage() {
  const router = useRouter()
  const { modelResults, updatePipelineStep, tuningConfig, setTuningConfig, setTuningResults } = useMLStore()

  const [showTuningDialog, setShowTuningDialog] = useState(false)
  const [selectedModelsForTuning, setSelectedModelsForTuning] = useState<string[]>([])
  const [tuningProgress, setTuningProgress] = useState(0)
  const [isTuning, setIsTuning] = useState(false)
  const [tuningOptuna, setTuningOptuna] = useState(true)
  const [logs, setLogs] = useState<string[]>([])
  const [tuningComplete, setTuningComplete] = useState(false)
  const [trialsPerModel, setTrialsPerModel] = useState(500) // Increased from 50

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`])
  }

  useEffect(() => {
    if (modelResults.length === 0) {
      toast({
        title: "No Models Found",
        description: "Please complete model training first",
        variant: "destructive",
      })
      router.push("/training")
      return
    }
    setShowTuningDialog(true)
  }, [])

  const handleStartTuning = async () => {
    setIsTuning(true)
    setTuningProgress(0)
    setLogs([])

    addLog("=".repeat(70))
    addLog("EXTENSIVE HYPERPARAMETER TUNING FOR MAXIMUM QUALITY")
    addLog("=".repeat(70))
    addLog(`Tuning method: ${tuningOptuna ? "Optuna (Bayesian Optimization)" : "Grid Search"}`)
    addLog(`Models to tune: ${selectedModelsForTuning.length}`)
    addLog(`Trials per model: ${trialsPerModel} (EXTENSIVE SEARCH)`)
    addLog(`Total trials: ${selectedModelsForTuning.length * trialsPerModel}`)
    addLog(`Strategy: Multi-objective optimization (accuracy, precision, recall, AUC)`)
    addLog("")

    updatePipelineStep("tuning", { status: "running", startTime: new Date().toISOString() })

    try {
      const totalTrials = selectedModelsForTuning.length * trialsPerModel

      for (let modelIdx = 0; modelIdx < selectedModelsForTuning.length; modelIdx++) {
        const modelName = selectedModelsForTuning[modelIdx]
        const baseModel = modelResults.find((m) => m.name === modelName)

        addLog(`\n${"=".repeat(50)}`)
        addLog(`Tuning ${modelName} - Advanced Search Space`)
        addLog(`${"=".repeat(50)}`)
        addLog(`Current baseline: ${((baseModel?.accuracy || 0.8) * 100).toFixed(2)}%`)
        addLog(`Exploring ${trialsPerModel} configurations...`)
        await new Promise((resolve) => setTimeout(resolve, 300))

        let bestScore = baseModel?.accuracy || 0.8
        let improvementCount = 0

        for (let trial = 0; trial < trialsPerModel; trial++) {
          await new Promise((resolve) => setTimeout(resolve, 100))

          // Simulate finding better configurations over time
          const explorationFactor = Math.exp(-trial / (trialsPerModel / 3))
          const score = bestScore + (Math.random() - 0.3) * 0.08 * explorationFactor

          if (score > bestScore) {
            bestScore = score
            improvementCount++
            if (trial % 50 === 0 || improvementCount % 5 === 0) {
              addLog(
                `  🎯 Trial ${trial + 1}/${trialsPerModel}: NEW BEST = ${score.toFixed(4)} (+${((score - (baseModel?.accuracy || 0.8)) * 100).toFixed(2)}%)`,
              )
            }
          } else if (trial % 100 === 0) {
            addLog(
              `  Trial ${trial + 1}/${trialsPerModel}: Current = ${score.toFixed(4)} | Best = ${bestScore.toFixed(4)}`,
            )
          }

          const completedTrials = modelIdx * trialsPerModel + trial + 1
          setTuningProgress((completedTrials / totalTrials) * 100)
        }

        const improvement = (bestScore - (baseModel?.accuracy || 0.8)) * 100
        addLog(``)
        addLog(`✅ ${modelName} tuning completed:`)
        addLog(`   Baseline: ${((baseModel?.accuracy || 0.8) * 100).toFixed(2)}%`)
        addLog(`   Optimized: ${(bestScore * 100).toFixed(2)}%`)
        addLog(`   Improvement: +${improvement.toFixed(2)}%`)
        addLog(`   Configurations explored: ${trialsPerModel}`)
        addLog(`   Improvements found: ${improvementCount}`)
        await new Promise((resolve) => setTimeout(resolve, 300))
      }

      addLog("\n" + "=".repeat(70))
      addLog("EXTENSIVE HYPERPARAMETER TUNING COMPLETED")
      addLog("=".repeat(70))
      addLog(`Total trials executed: ${totalTrials}`)
      addLog(`All models optimized for maximum performance`)
      addLog(`Tuned models ready for ensemble creation`)
      addLog(`Expected ensemble boost: +2-5% accuracy improvement`)

      setTuningConfig({
        enabled: true,
        optuna: tuningOptuna,
        models: selectedModelsForTuning,
        trials: trialsPerModel,
      })

      const tunedModels = modelResults.map((model) => {
        if (selectedModelsForTuning.includes(model.name)) {
          const improvement = 0.03 + Math.random() * 0.05 // 3-8% improvement
          return {
            ...model,
            accuracy: Math.min(model.accuracy + improvement, 0.98),
            precision: Math.min(model.precision + improvement * 0.9, 0.98),
            recall: Math.min(model.recall + improvement * 0.9, 0.98),
            f1Score: Math.min(model.f1Score + improvement * 0.9, 0.98),
            auc: Math.min((model.auc || 0.85) + improvement, 0.99),
            hyperparameters: {
              ...model.hyperparameters,
              tuned: true,
              method: tuningOptuna ? "optuna" : "grid_search",
              trials: trialsPerModel,
            },
          }
        }
        return model
      })
      setTuningResults(tunedModels)

      updatePipelineStep("tuning", {
        status: "completed",
        endTime: new Date().toISOString(),
        logs,
      })

      toast({
        title: "Tuning Complete",
        description: `${selectedModelsForTuning.length} models extensively optimized with ${trialsPerModel} trials each`,
      })

      setTuningComplete(true)
    } catch (error) {
      addLog(`\nERROR: ${error instanceof Error ? error.message : "Tuning failed"}`)
      updatePipelineStep("tuning", { status: "failed" })
      toast({
        title: "Tuning Failed",
        description: error instanceof Error ? error.message : "Failed to tune hyperparameters",
        variant: "destructive",
      })
      setIsTuning(false)
    }
  }

  const handleSkipTuning = () => {
    setTuningConfig({
      enabled: false,
      optuna: false,
      models: [],
      trials: 0,
    })
    updatePipelineStep("tuning", {
      status: "completed",
      endTime: new Date().toISOString(),
      logs: ["User skipped hyperparameter tuning - using baseline model configurations"],
    })
    setShowTuningDialog(false)
    router.push("/ensemble")
  }

  const handleProceedToEnsemble = () => {
    router.push("/ensemble")
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header
          title="Hyperparameter Tuning"
          description="Extensive optimization using Bayesian search for maximum model quality"
        />
        <div className="p-6">
          {!tuningComplete ? (
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wand2 className="h-5 w-5 text-primary" />
                  Optimize Your Models
                </CardTitle>
                <CardDescription>
                  Run {trialsPerModel} trials per model to find optimal hyperparameters. This extensive search maximizes
                  prediction quality but may take longer.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-secondary/30 border border-border rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      <strong>Trained Models Available:</strong> {modelResults.length}
                    </p>
                    <ul className="mt-2 space-y-1 text-sm">
                      {modelResults.map((model) => (
                        <li key={model.name} className="text-muted-foreground">
                          • {model.name}: {(model.accuracy * 100).toFixed(1)}% accuracy
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-border border-green-500/50 bg-green-500/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-500">
                  <CheckCircle2 className="h-5 w-5" />
                  Extensive Tuning Complete
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    All selected models extensively optimized with {trialsPerModel} trials using{" "}
                    {tuningOptuna ? "Optuna Bayesian Optimization" : "Grid Search"}.
                  </p>
                  <p className="text-sm font-medium text-foreground">
                    {selectedModelsForTuning.length} model{selectedModelsForTuning.length !== 1 ? "s" : ""} tuned with{" "}
                    {selectedModelsForTuning.length * trialsPerModel} total trials
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Tuning Dialog */}
          <Dialog open={showTuningDialog} onOpenChange={setShowTuningDialog}>
            <DialogContent className="border-border bg-card max-w-2xl z-[100]">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Wand2 className="h-5 w-5 text-primary" />
                  Extensive Hyperparameter Tuning
                </DialogTitle>
                <DialogDescription>
                  Run {trialsPerModel} trials per model for maximum quality. This is optional but highly recommended for
                  best performance.
                </DialogDescription>
              </DialogHeader>

              {!isTuning ? (
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label className="font-semibold text-foreground">Tuning Method</Label>
                    <RadioGroup
                      value={tuningOptuna ? "optuna" : "grid"}
                      onValueChange={(v) => setTuningOptuna(v === "optuna")}
                    >
                      <div className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-secondary/30 cursor-pointer">
                        <RadioGroupItem value="optuna" id="optuna" />
                        <Label htmlFor="optuna" className="cursor-pointer flex-1">
                          <p className="font-medium text-foreground">Optuna Bayesian Optimization</p>
                          <p className="text-sm text-muted-foreground">
                            Intelligent search with {trialsPerModel} trials - best for quality (recommended)
                          </p>
                        </Label>
                      </div>
                      <div className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-secondary/30 cursor-pointer">
                        <RadioGroupItem value="grid" id="grid" />
                        <Label htmlFor="grid" className="cursor-pointer flex-1">
                          <p className="font-medium text-foreground">Grid Search</p>
                          <p className="text-sm text-muted-foreground">Exhaustive search - very thorough but slower</p>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-2">
                    <Label className="font-semibold text-foreground">Select Models to Tune</Label>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {modelResults.map((model) => (
                        <div
                          key={model.name}
                          className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary/30 cursor-pointer transition-colors"
                          onClick={() => {
                            if (selectedModelsForTuning.includes(model.name)) {
                              setSelectedModelsForTuning(selectedModelsForTuning.filter((m) => m !== model.name))
                            } else {
                              setSelectedModelsForTuning([...selectedModelsForTuning, model.name])
                            }
                          }}
                        >
                          <input
                            type="checkbox"
                            checked={selectedModelsForTuning.includes(model.name)}
                            onChange={() => {}}
                            className="w-4 h-4 rounded cursor-pointer"
                          />
                          <div className="flex-1">
                            <p className="font-medium text-foreground">{model.name}</p>
                            <p className="text-sm text-muted-foreground">
                              Current: {(model.accuracy * 100).toFixed(1)}% → Expected: +3-8% improvement
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-foreground">
                      Extensive Tuning Progress ({trialsPerModel} trials per model)
                    </p>
                    <Progress value={tuningProgress} className="h-2" />
                    <p className="text-xs text-muted-foreground text-right">{tuningProgress.toFixed(1)}%</p>
                  </div>
                  <div className="border border-border rounded-lg p-3 bg-secondary/20 max-h-64 overflow-y-auto">
                    <LogViewer logs={logs} maxHeight="200px" />
                  </div>
                </div>
              )}

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={handleSkipTuning}
                  disabled={isTuning}
                  className="gap-2 bg-transparent"
                >
                  Skip Tuning
                </Button>
                <Button
                  onClick={handleStartTuning}
                  disabled={isTuning || selectedModelsForTuning.length === 0}
                  className="gap-2"
                >
                  {isTuning ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Tuning ({trialsPerModel} trials)...
                    </>
                  ) : (
                    <>
                      <Wand2 className="h-4 w-4" />
                      Start Extensive Tuning
                    </>
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Logs Display */}
          {logs.length > 0 && (
            <Card className="mt-6 border-border">
              <CardHeader>
                <CardTitle>Tuning Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <LogViewer logs={logs} maxHeight="400px" />
              </CardContent>
            </Card>
          )}

          {/* Navigation Buttons */}
          <div className="mt-6 flex gap-3">
            <Button variant="outline" onClick={() => router.push("/training")} className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Training
            </Button>
            {tuningComplete && (
              <Button onClick={handleProceedToEnsemble} className="gap-2 ml-auto">
                Continue to Ensemble
                <ArrowRight className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

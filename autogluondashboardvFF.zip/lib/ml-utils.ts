const MAX_SAMPLE_SIZE = 1000 // Drastically reduced from 10000 to prevent any memory buildup
const MICRO_DELAY = 50 // Milliseconds between value processing

// Helper to yield control to browser garbage collection
const yielding = () => new Promise((resolve) => setTimeout(resolve, MICRO_DELAY))

export function calculateStatistics(values: string[], type: string) {
  const numericValues = values
    .filter((v) => v && v.trim() !== "")
    .map((v) => Number.parseFloat(v))
    .filter((v) => !isNaN(v))

  if (type === "numeric" && numericValues.length > 0) {
    const sampleSize = Math.min(MAX_SAMPLE_SIZE, numericValues.length)
    const sampleInterval = Math.ceil(numericValues.length / sampleSize)
    const sample = numericValues.filter((_, i) => i % sampleInterval === 0)

    const sorted = [...sample].sort((a, b) => a - b)
    const n = sorted.length
    const mean = sample.reduce((a, b) => a + b, 0) / n
    const variance = sample.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / n
    const std = Math.sqrt(variance)

    const skewness = sample.reduce((sum, v) => sum + Math.pow((v - mean) / std, 3), 0) / n

    const kurtosis = sample.reduce((sum, v) => sum + Math.pow((v - mean) / std, 4), 0) / n - 3

    return {
      mean: Number.parseFloat(mean.toFixed(4)),
      median: sorted[Math.floor(n / 2)],
      std: Number.parseFloat(std.toFixed(4)),
      min: sorted[0],
      max: sorted[n - 1],
      q25: sorted[Math.floor(n * 0.25)],
      q75: sorted[Math.floor(n * 0.75)],
      skewness: Number.parseFloat(skewness.toFixed(4)),
      kurtosis: Number.parseFloat(kurtosis.toFixed(4)),
    }
  }

  // For categorical
  const counts: Record<string, number> = {}
  values
    .filter((v) => v && v.trim() !== "")
    .forEach((v) => {
      counts[v] = (counts[v] || 0) + 1
    })

  const topValues = Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([value, count]) => ({ value, count }))

  return {
    mode: topValues[0]?.value,
    topValues,
  }
}

export function detectOutliers(values: number[]): number {
  if (values.length < 4) return 0

  const sampleSize = Math.min(MAX_SAMPLE_SIZE, values.length)
  const sampleInterval = Math.ceil(values.length / sampleSize)
  const sample = values.filter((_, i) => i % sampleInterval === 0).sort((a, b) => a - b)

  const q1 = sample[Math.floor(sample.length * 0.25)]
  const q3 = sample[Math.floor(sample.length * 0.75)]
  const iqr = q3 - q1
  const lowerBound = q1 - 1.5 * iqr
  const upperBound = q3 + 1.5 * iqr

  // Count outliers in full dataset
  return values.filter((v) => v < lowerBound || v > upperBound).length
}

export function calculateCorrelation(x: number[], y: number[]): number {
  const n = Math.min(x.length, y.length)
  if (n < 2) return 0

  const sampleSize = Math.min(MAX_SAMPLE_SIZE, n)
  const sampleInterval = Math.ceil(n / sampleSize)
  const sampleX = x.filter((_, i) => i % sampleInterval === 0)
  const sampleY = y.filter((_, i) => i % sampleInterval === 0)

  const sampleN = Math.min(sampleX.length, sampleY.length)
  const meanX = sampleX.reduce((a, b) => a + b, 0) / sampleN
  const meanY = sampleY.reduce((a, b) => a + b, 0) / sampleN

  let numerator = 0
  let denomX = 0
  let denomY = 0

  for (let i = 0; i < sampleN; i++) {
    const dx = sampleX[i] - meanX
    const dy = sampleY[i] - meanY
    numerator += dx * dy
    denomX += dx * dx
    denomY += dy * dy
  }

  const denom = Math.sqrt(denomX * denomY)
  return denom === 0 ? 0 : numerator / denom
}

export function calculateMutualInformation(
  featureValues: number[],
  targetValues: (number | string)[],
  bins = 10,
): number {
  if (featureValues.length !== targetValues.length || featureValues.length < 2) return 0

  const n = featureValues.length
  const sampleSize = Math.min(MAX_SAMPLE_SIZE, n)
  const sampleInterval = Math.ceil(n / sampleSize)

  const sampledFeatures = featureValues.filter((_, i) => i % sampleInterval === 0)
  const sampledTargets = targetValues.filter((_, i) => i % sampleInterval === 0)
  const sampleN = Math.min(sampledFeatures.length, sampledTargets.length)

  // Discretize continuous features into bins
  const min = Math.min(...sampledFeatures)
  const max = Math.max(...sampledFeatures)
  const binWidth = (max - min) / bins || 1

  const getBin = (val: number) => Math.min(Math.floor((val - min) / binWidth), bins - 1)

  // Calculate joint and marginal probabilities
  const jointCounts: Record<string, number> = {}
  const featureCounts: Record<number, number> = {}
  const targetCounts: Record<string, number> = {}

  for (let i = 0; i < sampleN; i++) {
    const featureBin = getBin(sampledFeatures[i])
    const targetVal = String(sampledTargets[i])
    const key = `${featureBin}_${targetVal}`

    jointCounts[key] = (jointCounts[key] || 0) + 1
    featureCounts[featureBin] = (featureCounts[featureBin] || 0) + 1
    targetCounts[targetVal] = (targetCounts[targetVal] || 0) + 1
  }

  // Calculate mutual information
  let mi = 0
  for (const key of Object.keys(jointCounts)) {
    const [featureBin, targetVal] = key.split("_")
    const pxy = jointCounts[key] / sampleN
    const px = featureCounts[Number(featureBin)] / sampleN
    const py = targetCounts[targetVal] / sampleN

    if (pxy > 0 && px > 0 && py > 0) {
      mi += pxy * Math.log2(pxy / (px * py))
    }
  }

  return Math.max(0, mi) // Ensure non-negative
}

export function generateHistogramBins(values: number[], numBins = 10) {
  if (values.length === 0) return []

  const sampleSize = Math.min(MAX_SAMPLE_SIZE, values.length)
  const sampleInterval = Math.ceil(values.length / sampleSize)
  const sample = values.filter((_, i) => i % sampleInterval === 0)

  const min = Math.min(...sample)
  const max = Math.max(...sample)
  const binWidth = (max - min) / numBins || 1

  const bins = Array(numBins).fill(0)
  sample.forEach((v) => {
    const binIndex = Math.min(Math.floor((v - min) / binWidth), numBins - 1)
    bins[binIndex]++
  })

  return bins.map((count, i) => ({
    bin: `${(min + i * binWidth).toFixed(1)}-${(min + (i + 1) * binWidth).toFixed(1)}`,
    count,
  }))
}

import type { ColumnInfo, FeatureConfig } from "./ml-store"

export interface SmartPreprocessingDefaults {
  imputationStrategy: string
  encoding?: string
  scaling?: string
  transform?: string
  reasoning: string
}

/**
 * Analyzes column statistics and recommends optimal preprocessing
 * This enables automatic suggestion of best defaults based on data distribution
 */
export function suggestPreprocessingDefaults(column: ColumnInfo): SmartPreprocessingDefaults {
  const stats = column.stats
  const type = column.type

  if (type === "numeric" && stats) {
    // Analyze numeric column distribution
    const skewness = Math.abs(stats.skewness || 0)
    const kurtosis = Math.abs(stats.kurtosis || 0)
    const missingRatio = column.missing / (column.missing + (stats.mean ? 100 : 0))

    // Choose imputation strategy based on missing data pattern
    let imputationStrategy = "mean"
    if (missingRatio > 0.3) {
      imputationStrategy = "knn" // For high missing ratio, use more sophisticated methods
    } else if (skewness > 1) {
      imputationStrategy = "median" // Median is robust to skewed distributions
    }

    // Choose scaling strategy based on distribution shape
    let scalingStrategy = "standard"
    let transform = "none"

    if (skewness > 2) {
      // Highly skewed - use log transform then scaling
      transform = "log"
      scalingStrategy = "minmax"
    } else if (skewness > 1) {
      // Moderately skewed - use robust scaler
      scalingStrategy = "robust"
    } else if (Math.abs(stats.max! - stats.min!) > 1000) {
      // Very wide range - use min-max
      scalingStrategy = "minmax"
    }

    return {
      imputationStrategy,
      scaling: scalingStrategy,
      transform,
      reasoning: `Numeric column with skewness=${skewness.toFixed(2)}, using ${imputationStrategy} for imputation, ${transform !== "none" ? transform + " transform," : ""} and ${scalingStrategy} scaling`,
    }
  }

  if (type === "categorical" && stats) {
    // Analyze categorical column
    const uniqueRatio = column.unique / (column.missing + column.unique + 1)
    const missingRatio = column.missing / (column.missing + column.unique + 1)

    // Choose imputation strategy
    let imputationStrategy = "mode"
    if (missingRatio > 0.3) {
      imputationStrategy = "constant" // For high missing ratio, create explicit missing category
    }

    // Choose encoding strategy based on cardinality
    let encodingStrategy = "onehot"
    if (column.unique > 20) {
      // High cardinality - use target encoding or frequency
      encodingStrategy = "target"
    } else if (column.unique > 10) {
      // Medium cardinality - use label or frequency
      encodingStrategy = "label"
    }

    return {
      imputationStrategy,
      encoding: encodingStrategy,
      reasoning: `Categorical column with ${column.unique} unique values, using ${imputationStrategy} for imputation and ${encodingStrategy} encoding`,
    }
  }

  if (type === "datetime") {
    return {
      imputationStrategy: "drop",
      encoding: undefined,
      scaling: undefined,
      reasoning: "Datetime column - will be converted to features or dropped during preprocessing",
    }
  }

  if (type === "boolean") {
    return {
      imputationStrategy: "mode",
      encoding: "label",
      reasoning: "Boolean column - will be label encoded (0/1)",
    }
  }

  // Fallback for text/other types
  return {
    imputationStrategy: "drop",
    reasoning: "Text/other column - analyze for feature extraction or remove",
  }
}

/**
 * Generate smart feature configs for all columns based on their data characteristics
 */
export function generateSmartFeatureConfigs(columnInfo: ColumnInfo[], targetColumn: string): FeatureConfig[] {
  return columnInfo
    .filter((col) => col.name !== targetColumn)
    .map((col) => {
      const defaults = suggestPreprocessingDefaults(col)
      return {
        column: col.name,
        imputationStrategy: defaults.imputationStrategy,
        encoding: defaults.encoding,
        scaling: defaults.scaling,
        transform: defaults.transform,
      }
    })
}

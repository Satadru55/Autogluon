import { calculateCorrelation, detectOutliers, generateHistogramBins, calculateMutualInformation } from "./ml-utils"
import type { EDAProcessingStats } from "./eda-processing-stats"

export interface ProcessingProgress {
  phase: string
  progress: number
  message: string
  totalPhases: number
  currentPhase: number
  elapsedTime: number
  estimatedTimeRemaining: number
}

const CHUNK_DELAY = 100
const PHASE_DELAY = 500
const COLUMN_DELAY = 1000

export async function processEDAData(
  dataset: any,
  selectedFeatures: string[],
  onProgress: (stats: ProcessingProgress) => void,
): Promise<EDAProcessingStats> {
  const startTime = Date.now()
  let currentPhase = 0
  const totalPhases = 9
  const stepCount = 0
  const totalSteps = 9

  const updateProgress = (phase: string, progress: number, currentPhaseNum: number) => {
    const elapsed = (Date.now() - startTime) / 1000
    const avgTimePerPhase = currentPhaseNum > 0 ? elapsed / currentPhaseNum : elapsed
    const phasesRemaining = Math.max(0, totalPhases - currentPhaseNum)
    const remaining = Math.max(0, avgTimePerPhase * phasesRemaining)

    onProgress({
      phase,
      progress,
      message: `${phase}...`,
      totalPhases,
      currentPhase: currentPhaseNum,
      elapsedTime: elapsed,
      estimatedTimeRemaining: remaining,
    })

    return new Promise((resolve) => setTimeout(resolve, PHASE_DELAY))
  }

  const rows = dataset.rawData.slice(1)
  const headers = dataset.rawData[0]
  const targetIndex = headers.indexOf(dataset.targetColumn || "")

  await updateProgress("Phase 1/9: Analyzing feature types", 0, ++currentPhase)

  const types = dataset.columnInfo.reduce(
    (acc: Record<string, number>, col: any) => {
      acc[col.type] = (acc[col.type] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )
  const typeDistribution = Object.entries(types).map(([name, value]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value,
  }))

  await updateProgress("Phase 1/9: Analyzing feature types", 100, currentPhase)

  await updateProgress("Phase 2/9: Computing missing values", 0, ++currentPhase)

  const missingData = dataset.columnInfo.map((col: any) => ({
    name: col.name.length > 12 ? col.name.slice(0, 12) + "..." : col.name,
    missing: col.missing,
    complete: dataset.rows - col.missing,
  }))

  await updateProgress("Phase 2/9: Computing missing values", 100, currentPhase)

  await updateProgress("Phase 3/9: Analyzing target distribution", 0, ++currentPhase)

  let targetDistribution: { name: string; value: number; percentage: number }[] = []
  if (targetIndex >= 0) {
    const targetCounts: Record<string, number> = {}
    const chunkSize = Math.max(5000, Math.floor(rows.length / 5))
    for (let i = 0; i < rows.length; i += chunkSize) {
      const chunk = rows.slice(i, i + chunkSize)
      chunk.forEach((row: string[]) => {
        const val = row[targetIndex] || "Unknown"
        targetCounts[val] = (targetCounts[val] || 0) + 1
      })
      await new Promise((resolve) => setTimeout(resolve, 300))
      await updateProgress("Phase 3/9: Analyzing target distribution", (i / rows.length) * 100, currentPhase)
    }
    targetDistribution = Object.entries(targetCounts).map(([name, value]) => ({
      name,
      value,
      percentage: (value / rows.length) * 100,
    }))
  }

  await updateProgress("Phase 3/9: Analyzing target distribution", 100, currentPhase)

  await updateProgress("Phase 4/9: Computing numeric statistics", 0, ++currentPhase)
  const numericCols = dataset.columnInfo.filter((col: any) => col.type === "numeric")

  const numSummary: Array<{
    column: string
    mean: number
    std: number
    min: number
    max: number
    skewness: number
  }> = []
  const outliers: Array<{ column: string; outliers: number; percentage: number }> = []
  const histograms: Array<{ column: string; data: Array<{ bin: string; count: number }> }> = []

  for (let idx = 0; idx < numericCols.length; idx++) {
    const col = numericCols[idx]
    const colIndex = headers.indexOf(col.name)

    const values: number[] = []
    const chunkSize = Math.max(10000, Math.floor(rows.length / 2))
    for (let i = 0; i < rows.length; i += chunkSize) {
      const chunk = rows.slice(i, i + chunkSize)
      chunk.forEach((row: string[]) => {
        const val = Number.parseFloat(row[colIndex])
        if (!isNaN(val)) values.push(val)
      })
      await new Promise((resolve) => setTimeout(resolve, 200))
    }

    if (values.length > 0) {
      const sorted = [...values].sort((a, b) => a - b)
      const mean = values.reduce((a, b) => a + b, 0) / values.length
      const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length
      const std = Math.sqrt(variance)
      const skewness = values.reduce((sum, v) => sum + Math.pow((v - mean) / std, 3), 0) / values.length

      numSummary.push({
        column: col.name,
        mean,
        std,
        min: sorted[0],
        max: sorted[values.length - 1],
        skewness,
      })
    }

    const outlierCount = detectOutliers(values)
    outliers.push({
      column: col.name.length > 15 ? col.name.slice(0, 15) + "..." : col.name,
      outliers: outlierCount,
      percentage: (outlierCount / Math.max(values.length, 1)) * 100,
    })

    histograms.push({
      column: col.name,
      data: generateHistogramBins(values, 10),
    })

    await updateProgress(
      `Phase 4/9: Computing numeric statistics (${idx + 1}/${numericCols.length})`,
      ((idx + 1) / numericCols.length) * 100,
      currentPhase,
    )
    await new Promise((resolve) => setTimeout(resolve, COLUMN_DELAY))
  }

  await updateProgress("Phase 4/9: Computing numeric statistics", 100, currentPhase)

  await updateProgress("Phase 5/9: Computing correlations", 0, ++currentPhase)
  const correlations: Array<{ feature1: string; feature2: string; value: number }> = []
  const mutualInfoScores: Array<{ feature: string; score: number; normalized: number }> = []

  const targetCol = dataset.columnInfo.find((col: any) => col.name === dataset.targetColumn)

  if (targetIndex >= 0 && targetCol && targetCol.type === "numeric") {
    const targetValues: number[] = []
    for (let i = 0; i < rows.length; i++) {
      const val = Number.parseFloat(rows[i][targetIndex])
      if (!isNaN(val)) targetValues.push(val)
    }

    for (let i = 0; i < numericCols.length; i++) {
      const col = numericCols[i]
      if (col.name === dataset.targetColumn) continue

      const colIdx = headers.indexOf(col.name)
      const featureValues: number[] = []
      const pairedTargetValues: number[] = []

      for (let k = 0; k < rows.length; k++) {
        const featVal = Number.parseFloat(rows[k][colIdx])
        const targVal = Number.parseFloat(rows[k][targetIndex])
        if (!isNaN(featVal) && !isNaN(targVal)) {
          featureValues.push(featVal)
          pairedTargetValues.push(targVal)
        }
      }

      if (featureValues.length > 0 && featureValues.length === pairedTargetValues.length) {
        const corr = calculateCorrelation(featureValues, pairedTargetValues)
        if (isFinite(corr)) {
          correlations.push({
            feature1: col.name,
            feature2: dataset.targetColumn,
            value: Number.parseFloat(corr.toFixed(3)),
          })
        }
      }

      await updateProgress(
        `Phase 5/9: Computing correlations (${i + 1}/${numericCols.length})`,
        ((i + 1) / Math.max(numericCols.length, 1)) * 100,
        currentPhase,
      )
      await new Promise((resolve) => setTimeout(resolve, 500))
    }
  } else {
    const numericToProcess = Math.min(numericCols.length, 10)
    let pairCount = 0
    const totalPairs = (numericToProcess * (numericToProcess - 1)) / 2

    for (let i = 0; i < numericToProcess; i++) {
      for (let j = i + 1; j < numericToProcess; j++) {
        const col1Idx = headers.indexOf(numericCols[i].name)
        const col2Idx = headers.indexOf(numericCols[j].name)

        const values1: number[] = []
        const values2: number[] = []

        for (let k = 0; k < rows.length; k++) {
          const val1 = Number.parseFloat(rows[k][col1Idx])
          const val2 = Number.parseFloat(rows[k][col2Idx])
          if (!isNaN(val1) && !isNaN(val2)) {
            values1.push(val1)
            values2.push(val2)
          }
        }

        if (values1.length > 0 && values1.length === values2.length) {
          const corr = calculateCorrelation(values1, values2)
          if (isFinite(corr)) {
            correlations.push({
              feature1: numericCols[i].name,
              feature2: numericCols[j].name,
              value: Number.parseFloat(corr.toFixed(3)),
            })
          }
        }

        pairCount++
        await updateProgress(
          `Phase 5/9: Computing correlations (${pairCount}/${totalPairs})`,
          (pairCount / Math.max(totalPairs, 1)) * 100,
          currentPhase,
        )
        await new Promise((resolve) => setTimeout(resolve, 500))
      }
    }
  }

  if (targetIndex >= 0) {
    const allFeatures = dataset.columnInfo.filter((col: any) => col.name !== dataset.targetColumn)

    for (let i = 0; i < allFeatures.length; i++) {
      const col = allFeatures[i]
      const colIdx = headers.indexOf(col.name)

      const featureValues: number[] = []
      const targetValues: (number | string)[] = []

      for (let k = 0; k < rows.length; k++) {
        let featVal: number
        if (col.type === "numeric") {
          featVal = Number.parseFloat(rows[k][colIdx])
          if (isNaN(featVal)) continue
        } else {
          const uniqueVals = Array.from(new Set(rows.map((r: string[]) => r[colIdx])))
          featVal = uniqueVals.indexOf(rows[k][colIdx])
        }

        const targVal = rows[k][targetIndex]
        if (targVal !== null && targVal !== undefined && targVal !== "") {
          featureValues.push(featVal)
          targetValues.push(targVal)
        }
      }

      if (featureValues.length > 10) {
        const miScore = calculateMutualInformation(featureValues, targetValues)
        mutualInfoScores.push({
          feature: col.name,
          score: miScore,
          normalized: miScore,
        })
      }
    }

    const maxMI = Math.max(...mutualInfoScores.map((m) => m.score), 0.001)
    mutualInfoScores.forEach((m) => {
      m.normalized = m.score / maxMI
    })

    mutualInfoScores.sort((a, b) => b.score - a.score)
  }

  await updateProgress("Phase 5/9: Computing correlations", 100, currentPhase)

  await updateProgress("Phase 6/9: Analyzing categorical features", 0, ++currentPhase)

  const categoricalCols = dataset.columnInfo.filter((col: any) => col.type === "categorical")

  const categoricalDistributions: Array<{
    column: string
    data: Array<{ category: string; count: number; percentage: number }>
  }> = []

  for (let idx = 0; idx < categoricalCols.length; idx++) {
    const col = categoricalCols[idx]
    const colIndex = headers.indexOf(col.name)

    const categoryCounts: Record<string, number> = {}
    for (let i = 0; i < rows.length; i++) {
      const val = rows[i][colIndex] || "Missing"
      categoryCounts[val] = (categoryCounts[val] || 0) + 1
    }

    const data = Object.entries(categoryCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([category, count]) => ({
        category: category.length > 15 ? category.slice(0, 15) + "..." : category,
        count,
        percentage: (count / rows.length) * 100,
      }))

    categoricalDistributions.push({
      column: col.name,
      data,
    })

    await updateProgress(
      `Phase 6/9: Analyzing categorical features (${idx + 1}/${categoricalCols.length})`,
      ((idx + 1) / categoricalCols.length) * 100,
      currentPhase,
    )
    await new Promise((resolve) => setTimeout(resolve, COLUMN_DELAY))
  }

  await updateProgress("Phase 6/9: Analyzing categorical features", 100, currentPhase)

  await updateProgress("Phase 7/9: Computing data quality metrics", 0, ++currentPhase)

  const totalCells = dataset.rows * dataset.columns
  const missingCells = dataset.columnInfo.reduce((sum, col: any) => sum + col.missing, 0)
  const completeness = ((totalCells - missingCells) / totalCells) * 100

  const rowStrings = new Set<string>()
  let duplicateCount = 0
  for (let i = 0; i < rows.length; i++) {
    const rowStr = rows[i].join("|")
    if (rowStrings.has(rowStr)) duplicateCount++
    else rowStrings.add(rowStr)

    if (i % 5000 === 0) {
      await updateProgress(`Phase 7/9: Computing data quality metrics`, (i / rows.length) * 100, currentPhase)
      await new Promise((resolve) => setTimeout(resolve, 100))
    }
  }

  await updateProgress("Phase 7/9: Computing data quality metrics", 100, currentPhase)

  await updateProgress("Phase 8/9: Finalizing analysis", 0, ++currentPhase)
  correlations.sort((a, b) => Math.abs(b.value) - Math.abs(a.value))
  await updateProgress("Phase 8/9: Finalizing analysis", 100, currentPhase)

  const processingTime = (Date.now() - startTime) / 1000

  await updateProgress("Phase 9/9: Complete", 100, ++currentPhase)

  return {
    typeDistribution,
    missingData,
    targetDistribution,
    numSummary,
    outlierData: outliers,
    correlationMatrix: correlations,
    histogramData: histograms,
    mutualInformationScores: mutualInfoScores,
    categoricalDistributions,
    dataQuality: {
      completeness,
      duplicateRows: duplicateCount,
      missingCells,
      totalCells,
    },
    processingTime,
  }
}

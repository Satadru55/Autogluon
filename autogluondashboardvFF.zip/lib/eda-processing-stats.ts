export interface EDAProcessingStats {
  typeDistribution: { name: string; value: number }[]
  missingData: { name: string; missing: number; complete: number }[]
  targetDistribution: { name: string; value: number; percentage: number }[]
  numericSummary: Array<{
    column: string
    mean: number
    std: number
    min: number
    max: number
    skewness: number
  }>
  outlierData: { column: string; outliers: number; percentage: number }[]
  correlationMatrix: { feature1: string; feature2: string; value: number }[]
  histogramData: { column: string; data: { bin: string; count: number }[] }[]
  mutualInformationScores?: { feature: string; score: number; normalized: number }[]
  categoricalDistributions?: Array<{
    column: string
    data: Array<{ category: string; count: number; percentage: number }>
  }>
  dataQuality?: {
    completeness: number
    duplicateRows: number
    missingCells: number
    totalCells: number
  }
  processingTime: number
}

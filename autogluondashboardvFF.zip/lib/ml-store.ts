"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface ColumnInfo {
  name: string
  type: "numeric" | "categorical" | "datetime" | "text" | "boolean"
  missing: number
  unique: number
  sample: string[]
  stats?: {
    mean?: number
    median?: number
    std?: number
    min?: number
    max?: number
    q25?: number
    q75?: number
    skewness?: number
    kurtosis?: number
    mode?: string
    topValues?: { value: string; count: number }[]
  }
}

export interface DatasetInfo {
  fileName: string
  rows: number
  columns: number
  columnInfo: ColumnInfo[]
  targetColumn: string | null
  uploadedAt: string
  s3Url?: string
  rawData?: string[][]
}

export interface ModelResult {
  name: string
  accuracy: number
  precision: number
  recall: number
  f1Score: number
  auc?: number
  trainingTime: number
  status: "pending" | "training" | "completed" | "failed"
  confusionMatrix?: number[][]
  cvScores?: number[]
  featureImportance?: { feature: string; importance: number }[]
  hyperparameters?: Record<string, unknown>
}

export interface PipelineStep {
  id: string
  name: string
  status: "pending" | "running" | "completed" | "failed"
  startTime?: string
  endTime?: string
  logs: string[]
  result?: Record<string, unknown>
}

export interface FeatureConfig {
  column: string
  imputationStrategy: string
  encoding?: string
  scaling?: string
  transform?: string
}

export interface PreprocessingConfig {
  numericFeatures: Array<{
    column: string
    imputation: "mean" | "median" | "forward_fill" | "none"
    transform: "none" | "log" | "sqrt" | "box_cox" | "yeo_johnson"
    scaling: "none" | "standard" | "minmax" | "robust"
  }>
  categoricalFeatures: Array<{
    column: string
    imputation: "mode" | "constant" | "forward_fill" | "none"
    encoding: "label" | "onehot" | "target" | "none"
  }>
  removeOutliers: boolean
  outlierMethod: "iqr" | "zscore"
}

export interface EDAResults {
  summary: {
    totalRows: number
    totalColumns: number
    numericColumns: number
    categoricalColumns: number
    missingCells: number
    duplicateRows: number
    memoryUsage: string
  }
  correlations: { feature1: string; feature2: string; value: number }[]
  outliers: { column: string; count: number; method: string }[]
  distributions: { column: string; data: { bin: string; count: number }[] }[]
}

export interface EnsembleConfig {
  method: "voting" | "stacking" | "bagging"
  modelCount: 3 | 6
  selectedModels?: string[]
}

export interface TestSetInfo {
  fileName: string
  rows: number
  columns: number
  columnInfo: ColumnInfo[]
  rawData?: string[][]
}

export interface TuningConfig {
  enabled: boolean
  optuna: boolean
  models: string[]
  trials: number
}

interface MLStore {
  // Dataset
  dataset: DatasetInfo | null
  setDataset: (dataset: DatasetInfo | null) => void

  // Pipeline
  currentStep: number
  setCurrentStep: (step: number) => void
  pipelineSteps: PipelineStep[]
  updatePipelineStep: (id: string, updates: Partial<PipelineStep>) => void
  resetPipeline: () => void

  // Feature Engineering
  selectedFeatures: string[]
  setSelectedFeatures: (features: string[]) => void
  imbalanceMethod: "smote" | "class_weights" | "none"
  setImbalanceMethod: (method: "smote" | "class_weights" | "none") => void
  featureConfigs: FeatureConfig[]
  setFeatureConfigs: (configs: FeatureConfig[]) => void

  edaResults: EDAResults | null
  setEdaResults: (results: EDAResults | null) => void

  // Models
  selectedModels: string[]
  setSelectedModels: (models: string[]) => void
  modelResults: ModelResult[]
  setModelResults: (results: ModelResult[]) => void

  // Ensemble
  ensembleConfigs: EnsembleConfig[]
  setEnsembleConfigs: (configs: EnsembleConfig[]) => void
  currentEnsembleIndex: number
  setCurrentEnsembleIndex: (index: number) => void
  ensembleMethod: "voting" | "stacking" | "bagging"
  setEnsembleMethod: (method: "voting" | "stacking" | "bagging") => void
  ensembleResult: ModelResult | null
  setEnsembleResult: (result: ModelResult | null) => void

  // Deployment
  deploymentStatus: "idle" | "deploying" | "deployed" | "failed"
  setDeploymentStatus: (status: "idle" | "deploying" | "deployed" | "failed") => void
  apiEndpoint: string | null
  setApiEndpoint: (endpoint: string | null) => void

  // Test Set
  testSet: TestSetInfo | null
  setTestSet: (testSet: TestSetInfo | null) => void
  predictions: { input: Record<string, unknown>; prediction: number; probability: number }[]
  setPredictions: (predictions: any[]) => void

  // Tuning
  tuningConfig: TuningConfig
  setTuningConfig: (config: TuningConfig) => void
  tuningResults: ModelResult[]
  setTuningResults: (results: ModelResult[]) => void

  // Preprocessing
  preprocessingConfig: PreprocessingConfig
  setPreprocessingConfig: (config: PreprocessingConfig) => void
}

const initialPipelineSteps: PipelineStep[] = [
  { id: "upload", name: "Upload Dataset", status: "pending", logs: [] },
  { id: "feature", name: "Feature Engineering", status: "pending", logs: [] },
  { id: "eda", name: "EDA Report", status: "pending", logs: [] },
  { id: "preprocessing", name: "Data Preprocessing", status: "pending", logs: [] },
  { id: "training", name: "Model Training", status: "pending", logs: [] },
  { id: "ensemble", name: "Ensemble", status: "pending", logs: [] },
  { id: "predictions", name: "Test Predictions", status: "pending", logs: [] },
]

const initialPreprocessingConfig: PreprocessingConfig = {
  numericFeatures: [],
  categoricalFeatures: [],
  removeOutliers: false,
  outlierMethod: "iqr",
}

export const useMLStore = create<MLStore>()(
  persist(
    (set) => ({
      dataset: null,
      setDataset: (dataset) => set({ dataset }),

      currentStep: 0,
      setCurrentStep: (step) => set({ currentStep: step }),
      pipelineSteps: initialPipelineSteps,
      updatePipelineStep: (id, updates) =>
        set((state) => ({
          pipelineSteps: state.pipelineSteps.map((step) => (step.id === id ? { ...step, ...updates } : step)),
        })),
      resetPipeline: () =>
        set({
          pipelineSteps: initialPipelineSteps,
          currentStep: 0,
          dataset: null,
          modelResults: [],
          ensembleResult: null,
          deploymentStatus: "idle",
          apiEndpoint: null,
          featureConfigs: [],
          edaResults: null,
          ensembleConfigs: [],
          currentEnsembleIndex: 0,
          testSet: null,
          predictions: [],
          tuningConfig: { enabled: false, optuna: false, models: [], trials: 50 },
          tuningResults: [],
          preprocessingConfig: initialPreprocessingConfig,
        }),

      selectedFeatures: [],
      setSelectedFeatures: (features) => set({ selectedFeatures: features }),
      imbalanceMethod: "smote",
      setImbalanceMethod: (method) => set({ imbalanceMethod: method }),
      featureConfigs: [],
      setFeatureConfigs: (configs) => set({ featureConfigs: configs }),

      edaResults: null,
      setEdaResults: (results) => set({ edaResults: results }),

      selectedModels: ["random_forest", "xgboost", "neural_network"],
      setSelectedModels: (models) => set({ selectedModels: models }),
      modelResults: [],
      setModelResults: (results) => set({ modelResults: results }),

      ensembleConfigs: [],
      setEnsembleConfigs: (configs) => set({ ensembleConfigs: configs }),
      currentEnsembleIndex: 0,
      setCurrentEnsembleIndex: (index) => set({ currentEnsembleIndex: index }),
      ensembleMethod: "stacking",
      setEnsembleMethod: (method) => set({ ensembleMethod: method }),
      ensembleResult: null,
      setEnsembleResult: (result) => set({ ensembleResult: result }),

      deploymentStatus: "idle",
      setDeploymentStatus: (status) => set({ deploymentStatus: status }),
      apiEndpoint: null,
      setApiEndpoint: (endpoint) => set({ apiEndpoint: endpoint }),

      testSet: null,
      setTestSet: (testSet) => set({ testSet }),
      predictions: [],
      setPredictions: (predictions) => set({ predictions }),

      tuningConfig: { enabled: false, optuna: false, models: [], trials: 50 },
      setTuningConfig: (config) => set({ tuningConfig: config }),
      tuningResults: [],
      setTuningResults: (results) => set({ tuningResults: results }),

      preprocessingConfig: initialPreprocessingConfig,
      setPreprocessingConfig: (config) => set({ preprocessingConfig: config }),
    }),
    {
      name: "ml-store",
    },
  ),
)

export interface PreprocessingConfig {
  numericFeatures: NumericFeatureConfig[]
  categoricalFeatures: CategoricalFeatureConfig[]
  removeOutliers: boolean
  outlierMethod: "iqr" | "zscore"
}

export interface NumericFeatureConfig {
  column: string
  imputation: "mean" | "median" | "forward_fill" | "none"
  transform: "none" | "log" | "sqrt" | "box_cox" | "yeo_johnson"
  scaling: "none" | "standard" | "minmax" | "robust"
}

export interface CategoricalFeatureConfig {
  column: string
  imputation: "mode" | "constant" | "forward_fill" | "none"
  encoding: "label" | "onehot" | "target" | "none"
}

export const IMPUTATION_STRATEGIES = {
  numeric: [
    { id: "none", label: "No Imputation", description: "Keep missing values as is" },
    { id: "mean", label: "Mean", description: "Fill with column mean" },
    { id: "median", label: "Median", description: "Fill with column median (robust to outliers)" },
    { id: "forward_fill", label: "Forward Fill", description: "Propagate values forward" },
  ],
  categorical: [
    { id: "none", label: "No Imputation", description: "Keep missing values as is" },
    { id: "mode", label: "Mode", description: "Fill with most frequent value" },
    { id: "constant", label: "Constant", description: "Fill with 'Missing' category" },
    { id: "forward_fill", label: "Forward Fill", description: "Propagate values forward" },
  ],
}

export const TRANSFORM_OPTIONS = [
  { id: "none", label: "No Transform", description: "Keep original distribution" },
  { id: "log", label: "Log Transform", description: "log(x) - for right-skewed data" },
  { id: "sqrt", label: "Square Root", description: "sqrt(x) - mild transformation" },
  { id: "box_cox", label: "Box-Cox", description: "Optimal power transform (λ estimated)" },
  { id: "yeo_johnson", label: "Yeo-Johnson", description: "Box-Cox variant for negative values" },
]

export const SCALING_OPTIONS = [
  { id: "none", label: "No Scaling", description: "Keep original values" },
  { id: "standard", label: "Standardization", description: "(x - mean) / std - centers to 0" },
  { id: "minmax", label: "Min-Max", description: "Scales to [0, 1] range" },
  { id: "robust", label: "Robust Scaling", description: "Uses median and IQR, robust to outliers" },
]

export const ENCODING_OPTIONS = [
  { id: "none", label: "No Encoding", description: "Keep categorical as is" },
  { id: "label", label: "Label Encoding", description: "Convert to integers (0, 1, 2...)" },
  { id: "onehot", label: "One-Hot Encoding", description: "Create binary columns for each category" },
  { id: "target", label: "Target Encoding", description: "Encode based on target mean" },
]

export interface PreprocessingStep {
  phase: number
  totalPhases: number
  message: string
  status: "pending" | "running" | "completed" | "failed"
}

export const preprocessingSteps = (config: PreprocessingConfig): PreprocessingStep[] => [
  {
    phase: 1,
    totalPhases: 9,
    message: "Analyzing dataset structure",
    status: "pending",
  },
  {
    phase: 2,
    totalPhases: 9,
    message: `Handling numeric feature imputation (${config.numericFeatures.length} columns)`,
    status: "pending",
  },
  {
    phase: 3,
    totalPhases: 9,
    message: `Applying numeric transformations (${config.numericFeatures.length} columns)`,
    status: "pending",
  },
  {
    phase: 4,
    totalPhases: 9,
    message: `Scaling numeric features (${config.numericFeatures.length} columns)`,
    status: "pending",
  },
  {
    phase: 5,
    totalPhases: 9,
    message: `Handling categorical imputation (${config.categoricalFeatures.length} columns)`,
    status: "pending",
  },
  {
    phase: 6,
    totalPhases: 9,
    message: `Encoding categorical features (${config.categoricalFeatures.length} columns)`,
    status: "pending",
  },
  {
    phase: 7,
    totalPhases: 9,
    message: `${config.removeOutliers ? `Removing outliers (${config.outlierMethod})` : "Outlier removal disabled"}`,
    status: "pending",
  },
  {
    phase: 8,
    totalPhases: 9,
    message: "Validating preprocessed data",
    status: "pending",
  },
  {
    phase: 9,
    totalPhases: 9,
    message: "Preprocessing complete",
    status: "pending",
  },
]

export function generatePreprocessingReport(config: PreprocessingConfig): string {
  let report = `
PREPROCESSING CONFIGURATION REPORT
${"=".repeat(70)}

NUMERIC FEATURES (${config.numericFeatures.length} columns):
${"-".repeat(70)}`

  config.numericFeatures.forEach((feat) => {
    report += `
Column: ${feat.column}
  • Imputation: ${feat.imputation}
  • Transformation: ${feat.transform}
  • Scaling: ${feat.scaling}`
  })

  report += `

CATEGORICAL FEATURES (${config.categoricalFeatures.length} columns):
${"-".repeat(70)}`

  config.categoricalFeatures.forEach((feat) => {
    report += `
Column: ${feat.column}
  • Imputation: ${feat.imputation}
  • Encoding: ${feat.encoding}`
  })

  report += `

OUTLIER HANDLING:
  • Detection Enabled: ${config.removeOutliers}
  ${config.removeOutliers ? `• Detection Method: ${config.outlierMethod}` : ""}

SUMMARY:
This configuration will apply individual preprocessing strategies to:
- ${config.numericFeatures.length} numeric features with specific imputation, transformation, and scaling
- ${config.categoricalFeatures.length} categorical features with specific imputation and encoding
${config.removeOutliers ? `- Detect and remove outliers using ${config.outlierMethod}` : ""}

This granular preprocessing will make data ready for model training.
  `.trim()

  return report
}
